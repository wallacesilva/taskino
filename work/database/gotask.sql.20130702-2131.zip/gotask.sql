-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tempo de Geração: 
-- Versão do Servidor: 5.5.27
-- Versão do PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `gotask`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_ci_sessions`
--

DROP TABLE IF EXISTS `go_ci_sessions`;
CREATE TABLE IF NOT EXISTS `go_ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `go_ci_sessions`
--

INSERT INTO `go_ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('21b9d486e64b2c53ae23c49fdbfc4dc9', '::1', 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 1372800582, 'a:1:{s:6:"member";a:6:{s:2:"id";s:1:"1";s:4:"name";s:13:"Wallace Silva";s:5:"email";s:17:"aliga12@gmail.com";s:8:"password";s:40:"7c4a8d09ca3762af61e59520943dc26494f8941b";s:6:"status";s:6:"active";s:10:"date_added";s:19:"2013-06-10 14:44:15";}}');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_configs`
--

DROP TABLE IF EXISTS `go_configs`;
CREATE TABLE IF NOT EXISTS `go_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_name` varchar(255) NOT NULL,
  `config_key` int(255) NOT NULL,
  `config_value` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_members`
--

DROP TABLE IF EXISTS `go_members`;
CREATE TABLE IF NOT EXISTS `go_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(41) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `go_members`
--

INSERT INTO `go_members` (`id`, `name`, `email`, `password`, `status`, `date_added`) VALUES
(1, 'Wallace Silva', 'aliga12@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'active', '2013-06-10 14:44:15'),
(3, 'Gustavo Di Calafiori', 'ghcalafiori@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'active', '2013-06-11 23:02:43');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_tasks`
--

DROP TABLE IF EXISTS `go_tasks`;
CREATE TABLE IF NOT EXISTS `go_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `assigned_to` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `privacy_type` enum('public','protected','private') NOT NULL DEFAULT 'public' COMMENT 'public todos veem, protected so com senha, private so quem vai fazer e quem criou',
  `total_percent` int(11) NOT NULL DEFAULT '0' COMMENT 'porcentagem ja realizada da tarefa, valor aproximado',
  `task_due_date` datetime DEFAULT NULL COMMENT 'data em que vence a tarefa, data do prazo',
  `date_finalized` datetime DEFAULT NULL COMMENT 'data em que foi finalizado',
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Extraindo dados da tabela `go_tasks`
--

INSERT INTO `go_tasks` (`id`, `name`, `description`, `assigned_to`, `priority`, `status`, `privacy_type`, `total_percent`, `task_due_date`, `date_finalized`, `created_by`, `date_added`) VALUES
(1, 'Primeira tarefa', 'bla bla bla', 1, 4, 2, 'public', 100, NULL, '2013-06-12 00:00:00', 1, '2013-06-10 20:15:17'),
(5, 'Tarefa teste', 'dsdsds', 3, 4, 2, 'public', 100, NULL, '2013-06-19 14:48:13', 1, '2013-06-11 23:01:04'),
(7, 'Adicionar imagem da embarcação enviado por Lucas', 'Adicionar no banco de dados, criar arquivo para fazer o mesmo pois não foi acessar o phpmyadmin, não possuo acesso de fora da empresa :(', 1, 3, 2, 'public', 100, NULL, '2013-06-19 14:02:09', 1, '2013-06-19 11:15:00'),
(9, 'Instalar e criar conexão VPN para acessar phpMyAdmin', 'Leo me passou arquivo para instalar OpenVPN para conectar ao banco de dados, usando phpMyAdmin. Devo instalar e colocar a pasta no diretorio "config" da aplicação dentro do arquivos de programas do Windows\n\nbaixar arquivo do openvpn \n \nhttp://proxy.cabtur.com.br/vpn/chave/wsilva_21.zip\n', 1, 3, 2, 'public', 100, NULL, '2013-06-19 10:13:18', 1, '2013-06-18 17:04:16'),
(11, 'Criar goLogistics e goTransfer para SBMOffshore', 'Criar goLogistics e goTransfer para SBM.\r\nInserir dados enviados por Lucas para adicionar.\r\nPara agilizar manter as tabelas: (niveis, tiposservico, comunidades, cidades)\r\n\r\nArquivo está em Excel enviado por email por Lucas Ribeiro.', 1, 2, 2, 'public', 100, NULL, '2013-06-19 14:03:05', 1, '2013-06-13 17:28:22'),
(12, 'Colocar versão do goLogistics e goTransfer da SBM online', 'Adicionar a versão criada com os dados inseridos no servidor para ficar disponivel online e via a seguinte URL \r\n\r\nhttp://www.gologistics.com.br/sbm/\r\n\r\nCriar login e senha para Leo Balard e Lucas Ribeiro.', 1, 3, 2, 'public', 100, NULL, '2013-06-14 11:28:04', 1, '2013-06-14 15:50:18'),
(13, 'Remover botão Gerar Planilha de Rooster no SBM', 'Lucas pediu para remover o botão "Gerar Planilha de Rooster" quando abre a página de gerenciamento de passageiros no goLogistics da SBM offshore.\r\n\r\nhttp://www.gologistics.com.br/sbm/', 1, 3, 2, 'public', 100, NULL, '2013-06-19 11:25:10', 1, '2013-06-19 11:07:13'),
(15, 'Corrigir erro de email no sbmoffshore', 'encontrei um erro de email quando realizava alterações na versão 2.0 goLogistics, adicionar correções na versão do sbm funcionando atualmente online.\r\n\r\nAguardar Lucas com internet pra subir alterações', 1, 2, 2, 'public', 100, NULL, '2013-06-20 12:54:22', 1, '2013-06-20 10:09:11'),
(17, 'Testando para Gustavo', 'wow', 3, 3, 1, 'public', 0, '0000-00-00 00:00:00', NULL, 1, '2013-06-27 00:15:24'),
(22, 'Continuar Social Mamy', 'Continuar de onde foi feito o Social Mamy.', 1, 3, 1, 'public', 0, '2013-07-31 00:00:00', NULL, 1, '2013-07-01 16:57:53'),
(23, 'Criar sistema basico para o Guia Local', 'Projeto sendo realizado com o Gabriel, ', 1, 3, 1, 'public', 0, '2013-07-31 00:00:00', NULL, 1, '2013-07-01 17:01:33'),
(24, 'Alterar privacidade da tarefa', 'Adicionar campo que controle quem pode ver a tarefa, podendo ser \r\npublic - todos veem\r\nprotected - somente com senha e quem criou ve\r\nprivate - so ve quem vai fazer e quem criou', 1, 3, 1, 'public', 0, '2013-07-17 00:00:00', NULL, 1, '2013-07-01 17:03:01'),
(25, 'Terminar RC Andaimes', 'Terminar alteracoes solicitadas pela rc andaimes e a agencia Chave', 1, 2, 1, 'public', 0, '2013-07-17 00:00:00', NULL, 1, '2013-07-01 17:04:14'),
(26, 'Criar sistema de blog  - postir', 'Criar sistema de blog mais simples que wordpress e layout maneiro tipo o Ghost\r\n\r\nVeja link do site do ghost que usar editor markdown\r\nhttp://tryghost.org/index.html\r\n', 1, 4, 1, 'public', 0, '2013-11-29 00:00:00', NULL, 1, '2013-07-01 17:06:46');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_tasks_log`
--

DROP TABLE IF EXISTS `go_tasks_log`;
CREATE TABLE IF NOT EXISTS `go_tasks_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `description` text NOT NULL,
  `category_log` varchar(255) NOT NULL COMMENT 'category/tipo de log general, created, assigned_to, commented',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=78 ;

--
-- Extraindo dados da tabela `go_tasks_log`
--

INSERT INTO `go_tasks_log` (`id`, `task_id`, `member_id`, `description`, `category_log`, `date_added`) VALUES
(1, 3, 1, 'Tarefa foi atualizada com sucesso', 'general', '2013-06-19 17:27:16'),
(2, 3, 1, 'Tarefa foi atualizada com sucesso', 'general', '2013-06-19 17:27:40'),
(3, 10, 1, 'Tarefa recebeu novo comentario.', 'commented', '2013-06-19 17:37:46'),
(4, 3, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-19 17:44:03'),
(5, 15, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-20 10:09:11'),
(6, 15, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-20 12:53:35'),
(7, 11, 1, 'Tarefa recebeu novo comentario.', 'commented', '2013-06-20 12:54:12'),
(8, 15, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-20 12:54:12'),
(9, 15, 1, 'Tarefa foi finalizada em 2013-06-20 12:54:22', 'finalized', '2013-06-20 12:54:22'),
(10, 16, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-20 15:33:14'),
(11, 16, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-21 01:56:58'),
(12, 16, 1, 'Tarefa recebeu novo arquivo. Link: file_id:1/ full_url:http://gotask.vs/go-uploads/2013-06/ae185df434b93af8bc18ae71229a062d.jpg', 'general', '2013-06-21 01:57:14'),
(13, 16, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-21 01:57:14'),
(14, 17, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-27 00:15:24'),
(15, 18, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-27 11:33:31'),
(16, 19, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-27 11:40:40'),
(17, 19, 1, 'Tarefa foi REMOVIDA com sucesso. ID:19', 'general', '2013-06-27 11:41:23'),
(18, 18, 1, 'Tarefa foi REMOVIDA com sucesso. ID:18', 'general', '2013-06-27 11:41:30'),
(19, 20, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-27 11:41:43'),
(20, 20, 1, 'Tarefa foi REMOVIDA com sucesso. ID:20', 'general', '2013-06-27 11:42:24'),
(21, 21, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-27 11:42:35'),
(22, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:22:20'),
(23, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:25:26'),
(24, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:26:22'),
(25, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:26:33'),
(26, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:27:19'),
(27, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:27:26'),
(28, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:27:32'),
(29, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:28:06'),
(30, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:28:57'),
(31, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:29:02'),
(32, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:29:30'),
(33, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:29:39'),
(34, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:30:15'),
(35, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:30:38'),
(36, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:30:51'),
(37, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:31:17'),
(38, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:32:51'),
(39, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:33:55'),
(40, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:35:15'),
(41, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:35:26'),
(42, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:35:56'),
(43, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:36:29'),
(44, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:36:38'),
(45, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:36:51'),
(46, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:37:08'),
(47, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:37:22'),
(48, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:37:33'),
(49, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:39:17'),
(50, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:46:44'),
(51, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:47:02'),
(52, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:47:24'),
(53, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:47:40'),
(54, 13, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:47:52'),
(55, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 17:23:02'),
(56, 21, 1, 'Tarefa teve a percentagem alterada para 53', 'general', '2013-06-27 17:23:13'),
(57, 21, 1, 'Tarefa teve a percentagem alterada para 53', 'general', '2013-06-27 17:23:35'),
(58, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 17:30:12'),
(59, 21, 1, 'Tarefa teve a percentagem alterada para 37', 'general', '2013-06-27 17:30:20'),
(60, 21, 1, 'Tarefa teve a percentagem alterada para 58', 'general', '2013-06-27 17:30:57'),
(61, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-01 16:53:56'),
(62, 3, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-01 16:54:15'),
(63, 21, 1, 'Tarefa foi REMOVIDA com sucesso. ID:21', 'general', '2013-07-01 16:56:44'),
(64, 16, 1, 'Tarefa foi REMOVIDA com sucesso. ID:16', 'general', '2013-07-01 16:56:49'),
(65, 6, 1, 'Tarefa foi REMOVIDA com sucesso. ID:6', 'general', '2013-07-01 16:56:52'),
(66, 14, 1, 'Tarefa foi REMOVIDA com sucesso. ID:14', 'general', '2013-07-01 16:56:54'),
(67, 8, 1, 'Tarefa foi REMOVIDA com sucesso. ID:8', 'general', '2013-07-01 16:57:02'),
(68, 3, 1, 'Tarefa foi REMOVIDA com sucesso. ID:3', 'general', '2013-07-01 16:57:04'),
(69, 22, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-01 16:57:53'),
(70, 23, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-01 17:01:33'),
(71, 24, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-01 17:03:01'),
(72, 25, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-01 17:04:14'),
(73, 25, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-01 17:04:16'),
(74, 12, 1, 'Tarefa recebeu novo comentario.', 'commented', '2013-07-01 17:04:53'),
(75, 25, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-01 17:04:53'),
(76, 26, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-01 17:06:46'),
(77, 26, 1, 'Tarefa foi atualizada com sucesso', 'general', '2013-07-01 17:07:17');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_comments`
--

DROP TABLE IF EXISTS `go_task_comments`;
CREATE TABLE IF NOT EXISTS `go_task_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Extraindo dados da tabela `go_task_comments`
--

INSERT INTO `go_task_comments` (`id`, `task_id`, `subject`, `comment`, `created_by`, `date_added`) VALUES
(1, 3, 'First Comment', 'Wow :D', 1, '2013-06-17 16:48:24'),
(2, 3, 'Second Comment', 'Wow very funny', 1, '2013-06-17 16:48:44'),
(3, 11, 'Criado ', 'Criado sistema mas não foi colocado online, por falta de internet', 1, '2013-06-19 18:41:02'),
(4, 12, 'Disponivel online', 'Arquivos foram colocados online com a ajuda do Leonardo que criou o banco de dados e colocou os arquivos para mim que não tenho acesso ao banco de dados', 1, '2013-06-19 18:42:24'),
(5, 13, 'Removido', 'Botão foi removido hoje(19/06/2013) pela manhã, antes de eu ir almoçar.', 1, '2013-06-19 18:43:36'),
(6, 9, 'Feito mas nao resolvido', 'Criado conforme solicitado, porém não conseguimos resolver o problema de conexão com o banco via phpMyAdmin, como pode ser algo com a conexão via 3g, iremos aguardar a velox para que talvez seja possivel fazer isso.', 1, '2013-06-19 18:50:37'),
(7, 7, 'Adicionado', 'Imagem enviada pelo lucas via email foi adicionada pela manha gologistics da sbm.\r\n\r\nhttp://www.gologistics.com.br/sbm/principal.php\r\n', 1, '2013-06-19 18:51:43'),
(8, 11, 'já adicionado online', 'done com muito sacrificio mas colocamos(eu e Leonardo)', 1, '2013-06-19 14:02:50'),
(9, 3, 'aviso sobre essa alteracao', 'Será corrigido outros items antes que seja feito pois o visual pode complicar no futuro, então irei focar na funcionalidade', 1, '2013-06-19 14:04:40'),
(10, 3, 'Visao futura', 'Essa implementação será realizada somente na versão 2 do goLogistics e goTransfer', 1, '2013-06-19 17:37:46'),
(11, 15, 'Ok', 'Finalizado na parte da manha quando Lucas estava aqui rapidamente com internet.', 1, '2013-06-20 12:54:12'),
(12, 25, 'Cobraram agilidade', 'Adil me ligou hoje cobrando agilidade pois o cliente ta falando no ouvido dele.', 1, '2013-07-01 17:04:53');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_files`
--

DROP TABLE IF EXISTS `go_task_files`;
CREATE TABLE IF NOT EXISTS `go_task_files` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(11) unsigned NOT NULL,
  `description` varchar(255) NOT NULL COMMENT 'descricao para o arquivo',
  `filename` varchar(255) NOT NULL COMMENT 'nome do arquivo com extensao',
  `file_type` varchar(255) NOT NULL COMMENT 'tipo de arquivo',
  `full_path` varchar(255) NOT NULL COMMENT 'pasta onde foi feito upload',
  `full_url` varchar(255) NOT NULL COMMENT 'url direta para o arquivo',
  `is_image` tinyint(1) NOT NULL COMMENT 'informa se arquivo eh imagem',
  `file_size` varchar(255) NOT NULL COMMENT 'tamanho em kilobytes do arquivo',
  `created_by` int(11) unsigned NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `go_task_files`
--

INSERT INTO `go_task_files` (`id`, `task_id`, `description`, `filename`, `file_type`, `full_path`, `full_url`, `is_image`, `file_size`, `created_by`, `date_added`) VALUES
(1, 16, '', 'ae185df434b93af8bc18ae71229a062d.jpg', 'image/jpeg', '/go-uploads/2013-06/ae185df434b93af8bc18ae71229a062d.jpg', 'http://gotask.vs/go-uploads/2013-06/ae185df434b93af8bc18ae71229a062d.jpg', 1, '38.5', 1, '2013-06-21 01:57:13');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_todo`
--

DROP TABLE IF EXISTS `go_task_todo`;
CREATE TABLE IF NOT EXISTS `go_task_todo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
