-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tempo de Geração: 
-- Versão do Servidor: 5.5.27
-- Versão do PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `gotask`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_ci_sessions`
--

DROP TABLE IF EXISTS `go_ci_sessions`;
CREATE TABLE IF NOT EXISTS `go_ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_configs`
--

DROP TABLE IF EXISTS `go_configs`;
CREATE TABLE IF NOT EXISTS `go_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_name` varchar(255) NOT NULL,
  `config_key` int(255) NOT NULL,
  `config_value` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_members`
--

DROP TABLE IF EXISTS `go_members`;
CREATE TABLE IF NOT EXISTS `go_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(41) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_tasks`
--

DROP TABLE IF EXISTS `go_tasks`;
CREATE TABLE IF NOT EXISTS `go_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `assigned_to` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `privacy_type` enum('public','protected','private') NOT NULL DEFAULT 'public' COMMENT 'public todos veem, protected so com senha, private so quem vai fazer e quem criou',
  `total_percent` int(11) NOT NULL DEFAULT '0' COMMENT 'porcentagem ja realizada da tarefa, valor aproximado',
  `task_due_date` datetime DEFAULT NULL COMMENT 'data em que vence a tarefa, data do prazo',
  `date_finalized` datetime DEFAULT NULL COMMENT 'data em que foi finalizado',
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=45 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_tasks_log`
--

DROP TABLE IF EXISTS `go_tasks_log`;
CREATE TABLE IF NOT EXISTS `go_tasks_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `description` text NOT NULL,
  `category_log` varchar(255) NOT NULL COMMENT 'category/tipo de log general, created, assigned_to, commented',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=165 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_comments`
--

DROP TABLE IF EXISTS `go_task_comments`;
CREATE TABLE IF NOT EXISTS `go_task_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_files`
--

DROP TABLE IF EXISTS `go_task_files`;
CREATE TABLE IF NOT EXISTS `go_task_files` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(11) unsigned NOT NULL,
  `description` varchar(255) NOT NULL COMMENT 'descricao para o arquivo',
  `filename` varchar(255) NOT NULL COMMENT 'nome do arquivo com extensao',
  `file_type` varchar(255) NOT NULL COMMENT 'tipo de arquivo',
  `full_path` varchar(255) NOT NULL COMMENT 'pasta onde foi feito upload',
  `full_url` varchar(255) NOT NULL COMMENT 'url direta para o arquivo',
  `is_image` tinyint(1) NOT NULL COMMENT 'informa se arquivo eh imagem',
  `file_size` varchar(255) NOT NULL COMMENT 'tamanho em kilobytes do arquivo',
  `created_by` int(11) unsigned NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_todo`
--

DROP TABLE IF EXISTS `go_task_todo`;
CREATE TABLE IF NOT EXISTS `go_task_todo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
