-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 19/10/2013 às 03:59:57
-- Versão do Servidor: 5.5.23-55
-- Versão do PHP: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `in9web_taskino`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_ci_sessions`
--

DROP TABLE IF EXISTS `go_ci_sessions`;
CREATE TABLE IF NOT EXISTS `go_ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `go_ci_sessions`
--

INSERT INTO `go_ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('7ee0b2de0c2039fcddea876787287197', '186.194.46.246', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36', 1382139369, 'a:3:{s:12:"taskino_lang";s:10:"portuguese";s:6:"member";a:12:{s:2:"id";s:2:"19";s:10:"company_id";s:1:"1";s:4:"name";s:13:"Gabriel Bruno";s:5:"email";s:27:"gabrielmendoncanf@gmail.com";s:5:"login";s:7:"gabriel";s:6:"status";s:6:"active";s:16:"language_default";s:10:"portuguese";s:8:"is_admin";s:2:"no";s:15:"is_admin_master";s:2:"no";s:14:"activation_key";s:0:"";s:10:"date_added";s:19:"2013-09-18 22:53:25";s:15:"date_last_login";s:19:"2013-10-18 11:48:08";}s:7:"company";a:10:{s:2:"id";s:1:"1";s:4:"name";s:6:"in9web";s:5:"email";s:17:"aliga12@gmail.com";s:8:"url_logo";s:46:"http://in9web.com/media/images/logo-in9web.png";s:8:"codename";s:6:"in9web";s:11:"folder_name";s:6:"in9web";s:14:"plan_id_active";s:1:"2";s:14:"payment_status";s:9:"confirmed";s:16:"company_activate";N;s:10:"date_added";s:19:"2013-08-27 10:08:57";}}');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_configs`
--

DROP TABLE IF EXISTS `go_configs`;
CREATE TABLE IF NOT EXISTS `go_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `config_name` varchar(255) NOT NULL,
  `config_key` int(255) NOT NULL,
  `config_value` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_members`
--

DROP TABLE IF EXISTS `go_members`;
CREATE TABLE IF NOT EXISTS `go_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(41) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `language_default` varchar(255) NOT NULL DEFAULT 'portuguese' COMMENT 'define traducao padrao para o usuario, english/portuguese',
  `is_admin` enum('yes','no') NOT NULL DEFAULT 'no',
  `is_admin_master` enum('yes','no') NOT NULL DEFAULT 'no' COMMENT 'define se eh o admin da conta que nao pode deixar de ser admin',
  `activation_key` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Extraindo dados da tabela `go_members`
--

INSERT INTO `go_members` (`id`, `company_id`, `name`, `email`, `login`, `password`, `status`, `language_default`, `is_admin`, `is_admin_master`, `activation_key`, `date_added`, `date_last_login`) VALUES
(14, 1, 'Wallace Silva', 'aliga12@gmail.com', 'aliga12', '6aea9d536286f813ca629c9017e3369c8a0720dc', 'active', 'portuguese', 'yes', 'yes', '', '2013-08-27 10:08:57', '2013-10-08 07:12:14'),
(15, 5, 'Pedro ', 'pedro.bres@yahoo.com.br', 'brescianidesign', '4464d7b085a73cde0273f38d5b725c0b8c7944cc', 'active', 'portuguese', 'yes', 'yes', '', '2013-08-27 10:45:07', '2013-08-27 10:46:03'),
(16, 6, 'Rafaela', 'faela.fersi@gmail.com', 'Rafaela', 'b8a497e88503044cf7e82815ebd63527b450e201', 'active', 'portuguese', 'yes', 'yes', '', '2013-08-27 11:51:45', '2013-08-27 14:00:02'),
(17, 7, 'Gustavo', 'ghcalafiori@gmail.com', 'ghcalafiori', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'active', 'portuguese', 'yes', 'yes', '', '2013-09-01 09:35:48', '2013-09-01 09:36:47'),
(18, 8, 'weverthon', 'weverthon.davilla@gmail.com', 'weverthon', '490b2a992882b34875e3d0c607df44de981e41b5', 'active', 'portuguese', 'yes', 'yes', '', '2013-09-17 10:01:02', NULL),
(19, 1, 'Gabriel Bruno', 'gabrielmendoncanf@gmail.com', 'gabriel', 'ea425b7fc146ff6bd172909c455881fd6fddeeb0', 'active', 'portuguese', 'no', 'no', '', '2013-09-18 22:53:25', '2013-10-18 20:36:15'),
(20, 9, 'Wallace Silva', 'asidev2013@gmail.com', 'asidev', '727eee9c3a6255638ad1f5ee0b4365b5bfe65214', 'active', 'portuguese', 'yes', 'yes', '', '2013-09-19 08:52:22', '2013-10-18 14:14:09'),
(21, 10, 'Lessa', 'rebeccalessa@gmail.com', 'Becca', 'd1be900dd23213574eec6f8d93f3a6b60759e34a', 'active', 'portuguese', 'yes', 'yes', '', '2013-09-21 15:33:18', NULL),
(22, 11, 'teste', 'f90410bd@opayq.com', 'teste', '2e6f9b0d5885b6010f9167787445617f553a735f', 'active', 'portuguese', 'yes', 'yes', '', '2013-09-23 09:40:25', '2013-09-23 09:44:52'),
(23, 12, 'Flávio Sales', 'flaviosales@rondomotos.com.br', 'rm', '56875fc1b75772a8baceabbc88dc58f6f9c2b9af', 'active', 'portuguese', 'yes', 'yes', '', '2013-10-17 10:18:59', '2013-10-17 10:23:10'),
(24, 12, 'Oto Usuário', 'ti02@rondomotos.com.br', '1006', '56875fc1b75772a8baceabbc88dc58f6f9c2b9af', 'active', 'portuguese', 'no', 'no', '', '2013-10-17 10:30:56', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_member_company`
--

DROP TABLE IF EXISTS `go_member_company`;
CREATE TABLE IF NOT EXISTS `go_member_company` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `is_admin` enum('yes','no') NOT NULL DEFAULT 'no',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_member_options`
--

DROP TABLE IF EXISTS `go_member_options`;
CREATE TABLE IF NOT EXISTS `go_member_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_member_id` int(11) NOT NULL,
  `option_title` varchar(255) NOT NULL,
  `option_key` varchar(255) NOT NULL,
  `option_value` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_projects`
--

DROP TABLE IF EXISTS `go_projects`;
CREATE TABLE IF NOT EXISTS `go_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `total_percent` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Extraindo dados da tabela `go_projects`
--

INSERT INTO `go_projects` (`id`, `company_id`, `name`, `description`, `total_percent`, `priority`, `created_by`, `date_added`) VALUES
(5, 1, 'Projeto CMS', 'WOW nem acredito', 0, 2, 14, '2013-08-27 10:14:46'),
(6, 5, 'Edifica', 'Criação de Logo e cartão de visita', 0, 2, 15, '2013-08-27 10:48:11'),
(7, 6, 'COM-Vida Leôncio', 'Criação da Agenda 21 Escolar, da COM-Vida e envio do projeto pro MEC.', 0, 2, 16, '2013-08-27 11:53:27'),
(8, 9, 'Site - Asi Soluções', 'Desenvolvimento de breve site para novo dominio asisolucoes.com.br.\n\nComo modelo foi dado o que foi feito para Viana Off-Shore http://vianaoffshore.com.br/hotsite/.\n\nJá possui site atual em: www.asimacae.com.br', 0, 2, 20, '2013-09-19 08:56:42'),
(9, 9, 'Projeto Geral', 'Armazenar tudo que é realizado add por tarefas', 0, 2, 20, '2013-09-20 08:47:58'),
(10, 1, 'Projeto Taskino ', 'Esse mesmo sistemas que estamos a usar, adicionar correcoes e alteracoes.', 0, 2, 14, '2013-09-23 22:40:55'),
(11, 1, 'In9web', 'Controle de todo projeto relativo a empresa.', 0, 2, 19, '2013-10-09 17:23:48'),
(12, 1, 'Guia11', 'Projeto para controle das tarefas relativas ao site do guia11.com', 0, 2, 19, '2013-10-09 17:24:35'),
(13, 12, 'Novo Projeto', 'Este projeto é destinado ao conhecimento da ferramenta de gerenciamento de Projetos.', 0, 2, 23, '2013-10-17 10:25:01');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_report_bug`
--

DROP TABLE IF EXISTS `go_report_bug`;
CREATE TABLE IF NOT EXISTS `go_report_bug` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `where_find` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `go_report_bug`
--

INSERT INTO `go_report_bug` (`id`, `member_id`, `company_id`, `title`, `where_find`, `description`, `date_added`) VALUES
(1, 16, 6, 'Adicionar tarefas', 'Tarefas', 'Cadê o botão de adicionar tarefas?! o.O rsrs', '2013-08-27 11:54:42'),
(2, 22, 11, 'Adicionar Projeto', '', 'Na versão free, ao adicionar um projeto exibe uma mensagem de erro de que não é possível adicionar o projeto, pois alcançou o limite. Porém, não há projeto algum cadastrado. A versão free deveria permitir 5 projetos, não?!', '2013-09-23 09:43:49');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_company`
--

DROP TABLE IF EXISTS `go_taskino_company`;
CREATE TABLE IF NOT EXISTS `go_taskino_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `url_logo` varchar(255) NOT NULL,
  `codename` varchar(255) NOT NULL,
  `folder_name` varchar(255) NOT NULL,
  `plan_id_active` int(11) NOT NULL,
  `payment_status` varchar(255) NOT NULL COMMENT 'pending, confirmed, canceled',
  `company_activate` varchar(255) DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Extraindo dados da tabela `go_taskino_company`
--

INSERT INTO `go_taskino_company` (`id`, `name`, `email`, `url_logo`, `codename`, `folder_name`, `plan_id_active`, `payment_status`, `company_activate`, `date_added`) VALUES
(1, 'in9web', 'aliga12@gmail.com', 'http://in9web.com/media/images/logo-in9web.png', 'in9web', 'in9web', 2, 'confirmed', NULL, '2013-08-27 10:08:57'),
(5, 'Bresciani Design', 'pedro.bres@yahoo.com.br', '', 'Bresciani-Design', 'Bresciani-Design', 1, 'confirmed', NULL, '2013-08-27 10:45:07'),
(6, 'Ecolux Energia Inteligente', 'faela.fersi@gmail.com', '', 'Ecolux-Energia-Inteligente', 'Ecolux-Energia-Inteligente', 1, 'confirmed', NULL, '2013-08-27 11:51:45'),
(7, 'Sensee', 'ghcalafiori@gmail.com', '', 'Sensee', 'Sensee', 1, 'confirmed', NULL, '2013-09-01 09:35:48'),
(8, 'Weverthon', 'weverthon.davilla@gmail.com', '', 'Weverthon', 'Weverthon', 1, 'confirmed', NULL, '2013-09-17 10:01:02'),
(9, 'Asi Macae', 'asi-dev@ig.com.br', 'http://www.asimacae.com.br/site/pt-br/imagens/misc/logo_ASI.png', 'Asi-Macae', 'Asi-Macae', 1, 'confirmed', NULL, '2013-09-19 08:52:20'),
(10, 'Rebecca', 'rebeccalessa@gmail.com', '', 'Rebecca', 'Rebecca', 1, 'confirmed', NULL, '2013-09-21 15:33:17'),
(11, 'Teste', 'f90410bd@opayq.com', '', 'Teste', 'Teste', 1, 'confirmed', NULL, '2013-09-23 09:40:24'),
(12, 'Rondo Motos', 'flaviosales@rondomotos.com.br', '', 'Rondo-Motos', 'Rondo-Motos', 1, 'confirmed', NULL, '2013-10-17 10:18:59');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_company_options`
--

DROP TABLE IF EXISTS `go_taskino_company_options`;
CREATE TABLE IF NOT EXISTS `go_taskino_company_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `option_title` varchar(255) NOT NULL,
  `option_key` varchar(255) NOT NULL,
  `option_value` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_company_payments`
--

DROP TABLE IF EXISTS `go_taskino_company_payments`;
CREATE TABLE IF NOT EXISTS `go_taskino_company_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `plan_id` int(11) NOT NULL,
  `date_requested` datetime NOT NULL COMMENT 'data em que foi solicitado pagamento',
  `staff_member_confirmed_id` int(11) NOT NULL COMMENT 'id do usuario que aprovou pagamento',
  `date_confirmed` datetime NOT NULL COMMENT 'data em que pagamento foi confirmado',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='salvar historico de pagamentos das empresas' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_plans`
--

DROP TABLE IF EXISTS `go_taskino_plans`;
CREATE TABLE IF NOT EXISTS `go_taskino_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` varchar(255) NOT NULL,
  `max_filesize` int(11) NOT NULL COMMENT 'define maximo para upload, em Megabytes/MB',
  `max_tasks` int(11) NOT NULL,
  `max_projects` int(11) NOT NULL,
  `status` varchar(255) NOT NULL COMMENT 'definie se plano: active, inactive',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `go_taskino_plans`
--

INSERT INTO `go_taskino_plans` (`id`, `name`, `description`, `price`, `max_filesize`, `max_tasks`, `max_projects`, `status`, `date_added`) VALUES
(1, 'Free', '', '0', 100, 0, 20, 'active', '2013-07-30 11:20:27'),
(2, 'Professional i9web', 'Plan to enterprise in9web.', '0', 10000, 0, 100, 'active', '2013-09-23 22:01:09');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_staff_member`
--

DROP TABLE IF EXISTS `go_taskino_staff_member`;
CREATE TABLE IF NOT EXISTS `go_taskino_staff_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `is_admin` enum('yes','no') NOT NULL,
  `status` varchar(255) NOT NULL COMMENT 'active, inactive',
  `date_last_login` datetime NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='salva dados da equipe taskino' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_staff_member_options`
--

DROP TABLE IF EXISTS `go_taskino_staff_member_options`;
CREATE TABLE IF NOT EXISTS `go_taskino_staff_member_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_member_id` int(11) NOT NULL COMMENT 'id do membro da equipe taskino',
  `option_title` varchar(255) NOT NULL,
  `option_key` varchar(255) NOT NULL,
  `option_value` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_support_faq`
--

DROP TABLE IF EXISTS `go_taskino_support_faq`;
CREATE TABLE IF NOT EXISTS `go_taskino_support_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `faq_question` varchar(255) NOT NULL COMMENT 'pergunta ',
  `faq_answer` text NOT NULL COMMENT 'resposta',
  `support_topic_id` int(11) NOT NULL COMMENT 'id do topico relacionado com a pergunta',
  `author_name` varchar(255) NOT NULL COMMENT 'nome de quem fez a pergunta',
  `author_email` varchar(255) NOT NULL COMMENT 'email de quem fez a pergunta',
  `staff_member_id` int(11) NOT NULL COMMENT 'id do membro da equipe que aprovou pergunta',
  `status` varchar(255) NOT NULL COMMENT 'status da pergunta: active, pending, blocked',
  `date_approved` datetime NOT NULL COMMENT 'data em que foi aprovada',
  `date_added` datetime NOT NULL COMMENT 'data em que foi adicionada',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_support_topic`
--

DROP TABLE IF EXISTS `go_taskino_support_topic`;
CREATE TABLE IF NOT EXISTS `go_taskino_support_topic` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(255) NOT NULL COMMENT 'status do topico active, inactive',
  `staff_member_id` int(11) NOT NULL COMMENT 'membro do taskino que adicionou o topico',
  `date_added` datetime NOT NULL COMMENT 'data em que foi adicionado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_tasks`
--

DROP TABLE IF EXISTS `go_tasks`;
CREATE TABLE IF NOT EXISTS `go_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `assigned_to` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `privacy_type` enum('public','protected','private') NOT NULL DEFAULT 'public' COMMENT 'public todos veem, protected so com senha, private so quem vai fazer e quem criou',
  `task_folder` varchar(255) NOT NULL DEFAULT 'inbox' COMMENT 'local onde fica as tarefas, inbox, trash, archive',
  `total_percent` int(11) NOT NULL DEFAULT '0' COMMENT 'porcentagem ja realizada da tarefa, valor aproximado',
  `task_due_date` datetime DEFAULT NULL COMMENT 'data em que vence a tarefa, data do prazo',
  `date_finalized` datetime DEFAULT NULL COMMENT 'data em que foi finalizado',
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=75 ;

--
-- Extraindo dados da tabela `go_tasks`
--

INSERT INTO `go_tasks` (`id`, `project_id`, `company_id`, `name`, `description`, `assigned_to`, `priority`, `status`, `privacy_type`, `task_folder`, `total_percent`, `task_due_date`, `date_finalized`, `created_by`, `date_added`) VALUES
(1, NULL, 1, 'Arquivos de usuarios', 'Arquivos de usuarios', 1, 0, 2, 'private', 'archive', 100, NULL, '2013-08-27 09:56:21', 1, '2013-08-27 09:56:21'),
(50, 5, 1, 'Analisar projeto', 'começar analisando projeto', 14, 2, 1, 'public', 'inbox', 12, '2013-08-28 00:00:00', NULL, 14, '2013-08-27 10:15:08'),
(51, 6, 5, 'Logo', 'Criação de Logo da Empresa Edifica', 15, 2, 1, 'public', 'inbox', 0, '2013-09-05 00:00:00', NULL, 15, '2013-08-27 11:00:52'),
(52, 6, 5, 'Cartão de Visita', 'Criação de cartão de visita para a Empresa Edifica FRENTE/VERSO', 15, 2, 1, 'public', 'inbox', 0, '2013-09-05 00:00:00', NULL, 15, '2013-08-27 11:03:08'),
(53, 7, 6, 'Carteirinhas dos membros', 'Ver a arte das carteirinhas com Natália.', 16, 3, 2, 'public', 'trash', 100, '2013-09-03 14:01:32', '2013-08-27 14:03:52', 16, '2013-08-27 14:01:32'),
(54, 8, 9, 'Desenvolver breve site', 'Desenvolver layout simples e estruturar em html/css/js e mostrar para João Marcelo sobre.\n\nApós aprovado pegar dados para colocar online(ftp, login, senha....).\n\nComo modelo foi dado o que foi feito para Viana Off-Shore http://vianaoffshore.com.br/hotsite/.', 20, 3, 1, 'public', 'inbox', 1, '2013-09-26 00:00:00', NULL, 20, '2013-09-19 08:58:37'),
(55, 5, 1, 'Criar hospedagem para o cms.', 'Na minha visão, agente teria duas escolhas quando a hospedagem deste sistema. Agente poderia tanto colocar num domínio próprio quanto colocar com subdomínio da in9web.com.\n\nSendo que o domínio próprio poderia ser tipo in9cms.com e já como subdomínio cms.in9web.com.\n\nEu particularmente e inicialmente prefiro utilizar como subdomínio.', 14, 4, 1, 'public', 'inbox', 0, '2013-09-26 15:43:46', NULL, 19, '2013-09-19 15:43:46'),
(56, 5, 1, 'Centralizar cms - Criar subpastas com a configuração do cliente', '( pensei em algo tipo: cliente loga pelo subdomínio cliente.in9cms.com. Dentro desta pasta tem um arquivo de configuração deste cliente, quando o cliente acessa esta url, o script index.php dentro desta pasta já pega os dados de configuração e joga para a sessão e redireciona este cliente para o in9cms, para que ele possa efetuar o login.)\n\nE no caso do cliente acessar o endereço in9cms.com, diretamente ele será jogado para área de apresentação do sistema, com a versão demo, api e etc…\n\nPensando bem, poderiamos fazer até mais facilmente, sem precisar de um domínio próprio fazendo assim cms.in9web.com/cliente, então este cliente seria redirecionado para por exemplo: cms.in9web.com/login.php, com os dados dele já carregado na sessão.\n\nMais uma coisa, acho legal que o nome da pasta do cliente seja o domínio em questão e não um nome de usuário como se costuma fazer, acho que ficara mais organizado e poderemos diferenciar das nossas pastas internas, assim o endereço do cliente para acesso ao sistema seria: http://cms.in9web.com/sitedocliente.com.br, pensando nisso mais uma ideia! porque se o cliente logasse diretamente pelo formulário central de login ele só precisaria fazer o seguinte, ao invés de colocar somente o nome de usuário, ele colocaria o nome de usuário juntamente com o dominio do site, assim ficaria facil pra gente saber qual pasta utilizar para carregas as configurações ex: foo@bar.com.br.', 19, 3, 1, 'public', 'inbox', 0, '2013-09-26 15:49:44', NULL, 19, '2013-09-19 15:49:44'),
(57, 5, 1, 'Re-organizar módulos para novo layout', 'Como o layout anterior do sistema foi alterado.', 14, 3, 1, 'public', 'inbox', 0, '2013-09-26 15:56:42', NULL, 19, '2013-09-19 15:56:42'),
(58, 5, 1, 'Dashboard', 'Habilitar o funcionamento do dashboard', 14, 3, 1, 'public', 'inbox', 0, '2013-09-26 15:58:02', NULL, 19, '2013-09-19 15:58:02'),
(59, 5, 1, 'Site de apresentação', 'Desenvolver site de apresentação do sistema', 14, 3, 1, 'public', 'inbox', 0, '2013-09-26 16:00:39', NULL, 19, '2013-09-19 16:00:39'),
(60, 9, 9, 'Adaptar template', 'Adaptar conteúdo do site com template comprado por Joao Marcelo.\n', 20, 3, 1, 'public', 'inbox', 16, '2013-10-11 00:00:00', NULL, 20, '2013-09-20 08:49:59'),
(61, 8, 9, 'CMS - Mudanças', 'Realizar alterações no CMS da ASI. Chamado por enquanto de AsiCMS.', 20, 3, 1, 'public', 'inbox', 0, '2013-10-18 00:00:00', NULL, 20, '2013-09-23 10:40:42'),
(62, 10, 1, 'Listar Report Bugs', 'Criar area pra listar os report bugs enviados, analisar quais realmente sao importantes e relevantes.', 14, 4, 1, 'public', 'inbox', 0, '2013-10-11 00:00:00', NULL, 14, '2013-09-23 22:42:09'),
(63, 10, 1, 'Erro de ao adicionar novo projeto', 'Usuario informou que nao consegue adicionar mais projeto mesmo que nao tenha projetos no plano free, verificar possivel erro quando remove projetos e tenta adicionar novamente.', 14, 3, 1, 'public', 'inbox', 0, '2013-09-28 00:00:00', NULL, 14, '2013-09-23 22:44:12'),
(64, 9, 9, 'Site - Metalcald', 'Criação do site da metalcald, provavelmente usaremos template pois atualmente não temos WebDesigner nem designer.', 20, 3, 1, 'public', 'inbox', 0, '2013-10-11 00:00:00', NULL, 20, '2013-09-24 14:08:42'),
(65, 9, 9, 'Criar sistema de tarefas', 'Montar sistema de tarefas de forma que o gerenciador de tarefas e projetos seja somente uma parte de varias outras funcionalidades para gerenciar todas as atividades da empresa. Como por exemplo, help desk, controle de visitas ao cliente, dentre outros.', 20, 3, 1, 'public', 'inbox', 0, '2013-10-10 00:00:00', NULL, 20, '2013-09-24 14:10:56'),
(66, 9, 9, 'Sistema para politico', 'criar sistema para gerenciar filiados e outros dados relacionados', 20, 3, 2, 'public', 'inbox', 100, '2013-09-27 00:00:00', '2013-10-07 15:46:20', 20, '2013-09-25 16:19:18'),
(67, 12, 1, 'Criar ativação de conta por email', 'Para que não hajam pessoas se cadastrando sem um email válido e para que possamos assim ter uma lista de emails para enviar informações relativas ao projeto!', 19, 3, 1, 'public', 'inbox', 0, '2013-10-16 17:25:58', NULL, 19, '2013-10-09 17:25:58'),
(68, 12, 1, 'Criar área para recuperação de senha.', 'Criar recuperação de senha para pessoas que estão logando pela conta criada diretamente no site!', 19, 3, 1, 'public', 'inbox', 0, '2013-10-16 17:27:53', NULL, 19, '2013-10-09 17:27:53'),
(69, 12, 1, 'Adicionar notificação de castro no site.', 'Quando o usuário se cadastra no site ele deverá receber um email de boas vindas, informando das ferramentas.', 19, 3, 1, 'public', 'inbox', 0, '2013-10-16 17:32:05', NULL, 19, '2013-10-09 17:32:05'),
(70, 11, 1, 'Criar área para centralização das ferramentas que utilizamos', 'Essa é uma área importante para nossa organização, para não esquecermos de ver algum projeto, email, etc...', 14, 3, 1, 'public', 'inbox', 0, '2013-10-16 17:37:39', NULL, 19, '2013-10-09 17:37:39'),
(71, 13, 12, 'Primeira Tarefa', 'Primeira tarefa a ser desenvolvida para conhecimento da ferramenta de gerenciamento de projetos.', 23, 3, 1, 'public', 'inbox', 45, '2013-10-18 00:00:00', NULL, 23, '2013-10-17 10:26:40'),
(72, 13, 12, 'Ota Tarefa', 'Segunda tarefa do projeto.', 24, 2, 2, 'public', 'inbox', 100, '2013-10-24 10:31:56', '2013-10-17 10:45:51', 23, '2013-10-17 10:31:56'),
(73, 13, 12, 'Atrasada', 'Mais uma tarefa com data expirada.', 23, 1, 1, 'public', 'inbox', 0, '2013-10-24 10:47:33', NULL, 23, '2013-10-17 10:47:33'),
(74, 5, 1, 'Multi linguagem', 'Adicionar multi linguagem ao sistema de CMS', 14, 3, 1, 'public', 'inbox', 0, '2013-11-01 00:00:00', NULL, 19, '2013-10-18 12:32:49');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_tasks_log`
--

DROP TABLE IF EXISTS `go_tasks_log`;
CREATE TABLE IF NOT EXISTS `go_tasks_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `description` text NOT NULL,
  `category_log` varchar(255) NOT NULL COMMENT 'category/tipo de log general, created, assigned_to, commented',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=395 ;

--
-- Extraindo dados da tabela `go_tasks_log`
--

INSERT INTO `go_tasks_log` (`id`, `task_id`, `member_id`, `description`, `category_log`, `date_added`) VALUES
(331, 50, 14, 'Tarefa foi criada com sucesso', 'created', '2013-08-27 10:15:08'),
(332, 50, 14, 'Usuario Wallace Silva[14] notificado da tarefa Analisar projeto[50] por email', 'general', '2013-08-27 10:15:08'),
(333, 50, 14, 'Tarefa recebeu novo arquivo. Link: file_id:19/ full_url:http://in9web.com/app/taskino/taskino-uploads/in9web//1880168438322d3bb1780be45743e9ad.jpg', 'general', '2013-08-27 10:32:54'),
(334, 51, 15, 'Tarefa foi criada com sucesso', 'created', '2013-08-27 11:00:52'),
(335, 51, 15, 'Usuario Pedro [15] notificado da tarefa Logo[51] por email', 'general', '2013-08-27 11:00:52'),
(336, 52, 15, 'Tarefa foi criada com sucesso', 'created', '2013-08-27 11:03:08'),
(337, 52, 15, 'Usuario Pedro [15] notificado da tarefa Cartão de Visita[52] por email', 'general', '2013-08-27 11:03:08'),
(338, 53, 16, 'Tarefa foi criada com sucesso', 'created', '2013-08-27 14:01:32'),
(339, 53, 16, 'Usuario Rafaela[16] notificado da tarefa Carteirinhas dos membros[53] por email', 'general', '2013-08-27 14:01:32'),
(340, 53, 16, 'Tarefa foi finalizada em 2013-08-27 14:03:52', 'finalized', '2013-08-27 14:03:52'),
(341, 53, 16, 'Tarefa foi REMOVIDA com sucesso. ID:53', 'general', '2013-08-27 14:04:16'),
(342, 50, 14, 'Tarefa foi atualizada com sucesso', 'general', '2013-09-18 22:55:36'),
(343, 54, 20, 'Tarefa foi criada com sucesso', 'created', '2013-09-19 08:58:37'),
(344, 54, 20, 'Usuario Wallace Silva[20] notificado da tarefa Desenvolver breve site[54] por email', 'general', '2013-09-19 08:58:37'),
(345, 54, 20, 'Tarefa foi atualizada com sucesso', 'general', '2013-09-19 09:47:27'),
(346, 55, 19, 'Tarefa foi criada com sucesso', 'created', '2013-09-19 15:43:46'),
(347, 55, 19, 'Usuario Wallace Silva[14] notificado da tarefa Criar hospedagem para o cms.[55] por email', 'general', '2013-09-19 15:43:46'),
(348, 56, 19, 'Tarefa foi criada com sucesso', 'created', '2013-09-19 15:49:44'),
(349, 57, 19, 'Tarefa foi criada com sucesso', 'created', '2013-09-19 15:56:42'),
(350, 57, 19, 'Usuario Wallace Silva[14] notificado da tarefa Re-organizar módulos para novo layout[57] por email', 'general', '2013-09-19 15:56:42'),
(351, 58, 19, 'Tarefa foi criada com sucesso', 'created', '2013-09-19 15:58:02'),
(352, 58, 19, 'Usuario Wallace Silva[14] notificado da tarefa Dashboard[58] por email', 'general', '2013-09-19 15:58:02'),
(353, 59, 19, 'Tarefa foi criada com sucesso', 'created', '2013-09-19 16:00:39'),
(354, 59, 19, 'Usuario Wallace Silva[14] notificado da tarefa Site de apresentação[59] por email', 'general', '2013-09-19 16:00:39'),
(355, 54, 20, 'Tarefa recebeu novo arquivo. Link: file_id:20/ full_url:http://in9web.com/app/taskino/taskino-uploads/Asi-Macae//6719a71df5a726a6d5e276cdc68692c4.png', 'general', '2013-09-20 08:45:05'),
(356, 60, 20, 'Tarefa foi criada com sucesso', 'created', '2013-09-20 08:49:59'),
(357, 1, 20, 'Tarefa recebeu novo comentario.', 'commented', '2013-09-20 08:50:21'),
(358, 61, 20, 'Tarefa foi criada com sucesso', 'created', '2013-09-23 10:40:42'),
(359, 2, 14, 'Tarefa recebeu novo comentario.', 'commented', '2013-09-23 22:14:38'),
(360, 3, 14, 'Tarefa recebeu novo comentario.', 'commented', '2013-09-23 22:15:39'),
(361, 4, 14, 'Tarefa recebeu novo comentario.', 'commented', '2013-09-23 22:17:00'),
(362, 5, 14, 'Tarefa recebeu novo comentario.', 'commented', '2013-09-23 22:18:10'),
(363, 62, 14, 'Tarefa foi criada com sucesso', 'created', '2013-09-23 22:42:09'),
(364, 63, 14, 'Tarefa foi criada com sucesso', 'created', '2013-09-23 22:44:12'),
(365, 6, 20, 'Tarefa recebeu novo comentario.', 'commented', '2013-09-24 09:23:15'),
(366, 7, 20, 'Tarefa recebeu novo comentario.', 'commented', '2013-09-24 09:33:53'),
(367, 60, 20, 'Tarefa foi atualizada com sucesso', 'general', '2013-09-24 13:54:20'),
(368, 64, 20, 'Tarefa foi criada com sucesso', 'created', '2013-09-24 14:08:42'),
(369, 65, 20, 'Tarefa foi criada com sucesso', 'created', '2013-09-24 14:10:56'),
(370, 66, 20, 'Tarefa foi criada com sucesso', 'created', '2013-09-25 16:19:18'),
(371, 66, 20, 'Tarefa foi atualizada com sucesso', 'general', '2013-09-25 17:55:52'),
(372, 8, 20, 'Tarefa recebeu novo comentario.', 'commented', '2013-09-25 18:05:54'),
(373, 9, 20, 'Tarefa recebeu novo comentario.', 'commented', '2013-09-27 10:08:43'),
(374, 10, 20, 'Tarefa recebeu novo comentario.', 'commented', '2013-09-27 10:18:26'),
(375, 66, 20, 'Tarefa foi finalizada em 2013-10-07 15:46:20', 'finalized', '2013-10-07 15:46:20'),
(376, 67, 19, 'Tarefa foi criada com sucesso', 'created', '2013-10-09 17:25:58'),
(377, 68, 19, 'Tarefa foi criada com sucesso', 'created', '2013-10-09 17:27:53'),
(378, 69, 19, 'Tarefa foi criada com sucesso', 'created', '2013-10-09 17:32:05'),
(379, 70, 19, 'Tarefa foi criada com sucesso', 'created', '2013-10-09 17:37:39'),
(380, 71, 23, 'Tarefa foi criada com sucesso', 'created', '2013-10-17 10:26:40'),
(381, 71, 23, 'Usuario Flávio Sales[23] notificado da tarefa Primeira Tarefa[71] por email', 'general', '2013-10-17 10:26:40'),
(382, 71, 23, 'Tarefa foi atualizada com sucesso', 'general', '2013-10-17 10:27:32'),
(383, 72, 23, 'Tarefa foi criada com sucesso', 'created', '2013-10-17 10:31:56'),
(384, 72, 23, 'Tarefa foi encaminhada para Flávio Sales (id:23)', 'assigned_to', '2013-10-17 10:32:10'),
(385, 72, 23, 'Tarefa foi encaminhada para Oto Usuário (id:24)', 'assigned_to', '2013-10-17 10:32:18'),
(386, 11, 23, 'Tarefa recebeu novo comentario.', 'commented', '2013-10-17 10:32:55'),
(387, 72, 23, 'Tarefa recebeu novo arquivo. Link: file_id:21/ full_url:http://in9web.com/app/taskino/taskino-uploads/Rondo-Motos//4faa93c59fb64f6dcd7a538615e652f2.doc', 'general', '2013-10-17 10:38:40'),
(388, 72, 23, 'Tarefa recebeu novo arquivo. Link: file_id:22/ full_url:http://in9web.com/app/taskino/taskino-uploads/Rondo-Motos//418e0479d4a1a958b09383f0d4b9665d.png', 'general', '2013-10-17 10:41:22'),
(389, 12, 23, 'Tarefa recebeu novo comentario.', 'commented', '2013-10-17 10:42:41'),
(390, 72, 23, 'Tarefa foi atualizada com sucesso', 'general', '2013-10-17 10:44:34'),
(391, 72, 23, 'Tarefa foi finalizada em 2013-10-17 10:45:51', 'finalized', '2013-10-17 10:45:51'),
(392, 73, 23, 'Tarefa foi criada com sucesso', 'created', '2013-10-17 10:47:33'),
(393, 74, 19, 'Tarefa foi criada com sucesso', 'created', '2013-10-18 12:32:49'),
(394, 74, 19, 'Usuario Wallace Silva[14] notificado da tarefa Multi linguagem[74] por email', 'general', '2013-10-18 12:32:49');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_comments`
--

DROP TABLE IF EXISTS `go_task_comments`;
CREATE TABLE IF NOT EXISTS `go_task_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Extraindo dados da tabela `go_task_comments`
--

INSERT INTO `go_task_comments` (`id`, `task_id`, `subject`, `comment`, `created_by`, `date_added`) VALUES
(1, 60, 'Comprar template', 'Aguardando Joao comprar template desejado.', 20, '2013-09-20 08:50:21'),
(2, 56, 'Parecer', 'Achei muito legal isso, e acredito que seja ate bem rapido desenvolver tentarei fazer isso durante a semana. :)', 14, '2013-09-23 22:14:38'),
(3, 57, 'Parecer', 'Praticamente finalizado, se tem que procurar por pequenos erros que posso nao ter visto', 14, '2013-09-23 22:15:39'),
(4, 58, 'O que colocar?', 'temos que definir o que será exibido, to pensando em colocar pequenas informacoes da conta tipo plano e afins.\n\ndefinir o que sera adicionado :)', 14, '2013-09-23 22:17:00'),
(5, 59, 'Ok', 'Isso posso começar a fazer assim que terminar o principal do cms, vou procurar algo bem nos estilo de divulgar o projeto mesmo. :)', 14, '2013-09-23 22:18:10'),
(6, 61, 'Plugins', 'Pretendo adicionar sistema de plugins para facilitar a interação nos conteudos, nada tao similar ao wordpress.\n', 20, '2013-09-24 09:23:15'),
(7, 61, 'Pagina de albums - tema', 'no tema de exemplo adicionar albuns de cadastro.', 20, '2013-09-24 09:33:53'),
(8, 66, 'Filiados', 'Modulo de filiados terminado, nao ha verificacao de dados no form', 20, '2013-09-25 18:05:54'),
(9, 66, 'Erros e alterações', 'Envio de mail em  iso e cadastrar novo usuario senha nao exibe. \nfalha de cadastrar filiado nao redirecionar, modo debug.\nfeito', 20, '2013-09-27 10:08:43'),
(10, 66, 'Solicitacoes de atividade', '- adicionar id do filiado na listagem;\n- imprimir todos na listagem;\n- mudar dashboard -> avisos;\n- filtrar por nome, subgrupo ;\n- adicionar logo do psd no menu;\n- Visualizar(consultar) filiado/parceiro;', 20, '2013-09-27 10:18:26'),
(11, 72, 'Dificil', 'Eta tarega dificil', 23, '2013-10-17 10:32:55'),
(12, 72, 'Mais comentário', 'Mais comentário sobre a tarefa.', 23, '2013-10-17 10:42:41');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_files`
--

DROP TABLE IF EXISTS `go_task_files`;
CREATE TABLE IF NOT EXISTS `go_task_files` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(11) unsigned NOT NULL,
  `company_id` int(11) NOT NULL COMMENT 'id da empres ao qual pertence o arquivo, usado acelerar a consulta ',
  `description` varchar(255) NOT NULL COMMENT 'descricao para o arquivo',
  `filename` varchar(255) NOT NULL COMMENT 'nome do arquivo com extensao',
  `file_type` varchar(255) NOT NULL COMMENT 'tipo de arquivo',
  `full_path` varchar(255) NOT NULL COMMENT 'pasta onde foi feito upload',
  `full_url` varchar(255) NOT NULL COMMENT 'url direta para o arquivo',
  `is_image` tinyint(1) NOT NULL COMMENT 'informa se arquivo eh imagem',
  `file_size` varchar(255) NOT NULL COMMENT 'tamanho em kilobytes do arquivo',
  `hosted_on` varchar(255) NOT NULL DEFAULT 'taskino' COMMENT 'local onde esta o arquivo, taskino=servidor local, senao nome da empresa',
  `created_by` int(11) unsigned NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Extraindo dados da tabela `go_task_files`
--

INSERT INTO `go_task_files` (`id`, `task_id`, `company_id`, `description`, `filename`, `file_type`, `full_path`, `full_url`, `is_image`, `file_size`, `hosted_on`, `created_by`, `date_added`) VALUES
(20, 54, 9, 'logo transparent', '6719a71df5a726a6d5e276cdc68692c4.png', 'image/png', '/taskino-uploads/Asi-Macae/6719a71df5a726a6d5e276cdc68692c4.png', 'http://in9web.com/app/taskino/taskino-uploads/Asi-Macae//6719a71df5a726a6d5e276cdc68692c4.png', 1, '28.14', 'taskino', 20, '2013-09-20 08:45:05'),
(21, 72, 12, '', '4faa93c59fb64f6dcd7a538615e652f2.doc', 'application/msword', '/taskino-uploads/Rondo-Motos/4faa93c59fb64f6dcd7a538615e652f2.doc', 'http://in9web.com/app/taskino/taskino-uploads/Rondo-Motos//4faa93c59fb64f6dcd7a538615e652f2.doc', 0, '740.5', 'taskino', 23, '2013-10-17 10:38:40'),
(22, 72, 12, 'Imagen Upload', '418e0479d4a1a958b09383f0d4b9665d.png', 'image/png', '/taskino-uploads/Rondo-Motos/418e0479d4a1a958b09383f0d4b9665d.png', 'http://in9web.com/app/taskino/taskino-uploads/Rondo-Motos//418e0479d4a1a958b09383f0d4b9665d.png', 1, '441.64', 'taskino', 23, '2013-10-17 10:41:19');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
