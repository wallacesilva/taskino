-- phpMyAdmin SQL Dump
-- version 3.4.11.1
-- http://www.phpmyadmin.net
--
-- Máquina: localhost
-- Data de Criação: 02-Jul-2013 às 21:33
-- Versão do servidor: 5.5.23
-- versão do PHP: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de Dados: `walla537_taskino`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_ci_sessions`
--

DROP TABLE IF EXISTS `go_ci_sessions`;
CREATE TABLE IF NOT EXISTS `go_ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `go_ci_sessions`
--

INSERT INTO `go_ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('202e3e31703ec132ebec81910f6c6635', '186.194.55.65', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36', 1372638054, '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_configs`
--

DROP TABLE IF EXISTS `go_configs`;
CREATE TABLE IF NOT EXISTS `go_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_name` varchar(255) NOT NULL,
  `config_key` int(255) NOT NULL,
  `config_value` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_members`
--

DROP TABLE IF EXISTS `go_members`;
CREATE TABLE IF NOT EXISTS `go_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(41) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Extraindo dados da tabela `go_members`
--

INSERT INTO `go_members` (`id`, `name`, `email`, `password`, `status`, `date_added`) VALUES
(1, 'Wallace Silva', 'aliga12@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'active', '2013-06-10 14:44:15'),
(3, 'Gustavo Di Calafiori', 'ghcalafiori@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'active', '2013-06-11 23:02:43');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_tasks`
--

DROP TABLE IF EXISTS `go_tasks`;
CREATE TABLE IF NOT EXISTS `go_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `assigned_to` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `total_percent` int(11) NOT NULL DEFAULT '0' COMMENT 'porcentagem ja realizada da tarefa, valor aproximado',
  `task_due_date` datetime DEFAULT NULL COMMENT 'data em que vence a tarefa, data do prazo',
  `date_finalized` datetime DEFAULT NULL COMMENT 'data em que foi finalizado',
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Extraindo dados da tabela `go_tasks`
--

INSERT INTO `go_tasks` (`id`, `name`, `description`, `assigned_to`, `priority`, `status`, `total_percent`, `task_due_date`, `date_finalized`, `created_by`, `date_added`) VALUES
(1, 'Primeira tarefa', 'bla bla bla', 1, 4, 2, 100, NULL, '2013-06-12 00:00:00', 1, '2013-06-10 20:15:17'),
(3, 'Alterar template goLogistics2', 'anotado lorem ipsum, lorem ipsum, lorem ipsum, lorem ipsumlorem ipsum lorem ipsumlorem ipsum lorem ipsumlorem ipsum lorem ipsumlorem ipsum ', 1, 5, 1, 0, NULL, NULL, 1, '2013-06-17 14:04:58'),
(5, 'Tarefa teste', 'dsdsds', 3, 4, 2, 100, NULL, '2013-06-19 14:48:13', 1, '2013-06-11 23:01:04'),
(6, 'Alterar sistema de login no goLogistics', 'Falha permite acessar páginas sem login, assim como sistema de outros clientes.\r\n\r\nex. brasdril poderia acessar dados da sbm somente alterando a url', 1, 3, 1, 0, NULL, NULL, 1, '2013-06-13 14:05:16'),
(7, 'Adicionar imagem da embarcação enviado por Lucas', 'Adicionar no banco de dados, criar arquivo para fazer o mesmo pois não foi acessar o phpmyadmin, não possuo acesso de fora da empresa :(', 1, 3, 2, 100, NULL, '2013-06-19 14:02:09', 1, '2013-06-19 11:15:00'),
(8, 'Adicionar nova forma de conexao com o banco de dados', 'Criar uma nova forma de conexão com o banco de dados, sera usado a class Medoo que possibilita a criação de consultas, inserções e atualizações de dados no banco assim como possibilita a interoperabilidade entre bancos facilitando a migração para outros bancos de dados caso seja necessário no futuro.', 1, 3, 1, 0, NULL, NULL, 1, '2013-06-11 10:53:54'),
(9, 'Instalar e criar conexão VPN para acessar phpMyAdmin', 'Leo me passou arquivo para instalar OpenVPN para conectar ao banco de dados, usando phpMyAdmin. Devo instalar e colocar a pasta no diretorio "config" da aplicação dentro do arquivos de programas do Windows\n\nbaixar arquivo do openvpn \n \nhttp://proxy.cabtur.com.br/vpn/chave/wsilva_21.zip\n', 1, 3, 2, 100, NULL, '2013-06-19 10:13:18', 1, '2013-06-18 17:04:16'),
(11, 'Criar goLogistics e goTransfer para SBMOffshore', 'Criar goLogistics e goTransfer para SBM.\r\nInserir dados enviados por Lucas para adicionar.\r\nPara agilizar manter as tabelas: (niveis, tiposservico, comunidades, cidades)\r\n\r\nArquivo está em Excel enviado por email por Lucas Ribeiro.', 1, 2, 2, 100, NULL, '2013-06-19 14:03:05', 1, '2013-06-13 17:28:22'),
(12, 'Colocar versão do goLogistics e goTransfer da SBM online', 'Adicionar a versão criada com os dados inseridos no servidor para ficar disponivel online e via a seguinte URL \r\n\r\nhttp://www.gologistics.com.br/sbm/\r\n\r\nCriar login e senha para Leo Balard e Lucas Ribeiro.', 1, 3, 2, 100, NULL, '2013-06-14 11:28:04', 1, '2013-06-14 15:50:18'),
(13, 'Remover botão Gerar Planilha de Rooster no SBM', 'Lucas pediu para remover o botão "Gerar Planilha de Rooster" quando abre a página de gerenciamento de passageiros no goLogistics da SBM offshore.\r\n\r\nhttp://www.gologistics.com.br/sbm/', 1, 3, 2, 100, NULL, '2013-06-19 11:25:10', 1, '2013-06-19 11:07:13'),
(14, 'Criar git para o sistema do goLogistics e goTransfer', 'Colocar arquivos do goLogistics sendo melhorados e adaptados no git, estarei usando o bitBucket.org para salvar os dados e o repositório ficará como privado para preservar dados da empresa.\r\n\r\nInicialmente não será possível trabalhar com dados online, mas os commits serão salvos localmente na minha máquina para no futuro ser adicionado no servidor.\r\n\r\nPS. não será usado github, somente o sistema de controle de versão git.', 1, 3, 1, 0, NULL, NULL, 1, '2013-06-12 14:16:10'),
(15, 'Corrigir erro de email no sbmoffshore', 'encontrei um erro de email quando realizava alterações na versão 2.0 goLogistics, adicionar correções na versão do sbm funcionando atualmente online.\r\n\r\nAguardar Lucas com internet pra subir alterações', 1, 2, 2, 100, NULL, '2013-06-20 12:54:22', 1, '2013-06-20 10:09:11'),
(16, 'Criar ferramenta para facilitar criação de backups', 'Criar ferramenta que facilite criação de backups, pois atualmente tenho ficado sem internet e preciso fazer backup dos dados do goLogistics da sbm por exemplo e demora, o que é ruim pois nunca tenho muito tempo de internet.\r\n\r\nIrei criar algo como \r\nhttp://gologistics.com.br/tools/\r\n\r\nonde terá acesso somente com senha obvio e podera fazer o backup fácil dos arquivos e depois se possivel do banco de dados.\r\n', 1, 3, 1, 0, NULL, NULL, 1, '2013-06-20 15:33:14'),
(17, 'Testando para Gustavo', 'wow', 3, 3, 1, 0, '0000-00-00 00:00:00', NULL, 1, '2013-06-27 00:15:24');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_tasks_log`
--

DROP TABLE IF EXISTS `go_tasks_log`;
CREATE TABLE IF NOT EXISTS `go_tasks_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `description` text NOT NULL,
  `category_log` varchar(255) NOT NULL COMMENT 'category/tipo de log general, created, assigned_to, commented',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Extraindo dados da tabela `go_tasks_log`
--

INSERT INTO `go_tasks_log` (`id`, `task_id`, `member_id`, `description`, `category_log`, `date_added`) VALUES
(1, 3, 1, 'Tarefa foi atualizada com sucesso', 'general', '2013-06-19 17:27:16'),
(2, 3, 1, 'Tarefa foi atualizada com sucesso', 'general', '2013-06-19 17:27:40'),
(3, 10, 1, 'Tarefa recebeu novo comentario.', 'commented', '2013-06-19 17:37:46'),
(4, 3, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-19 17:44:03'),
(5, 15, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-20 10:09:11'),
(6, 15, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-20 12:53:35'),
(7, 11, 1, 'Tarefa recebeu novo comentario.', 'commented', '2013-06-20 12:54:12'),
(8, 15, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-20 12:54:12'),
(9, 15, 1, 'Tarefa foi finalizada em 2013-06-20 12:54:22', 'finalized', '2013-06-20 12:54:22'),
(10, 16, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-20 15:33:14'),
(11, 16, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-21 01:56:58'),
(12, 16, 1, 'Tarefa recebeu novo arquivo. Link: file_id:1/ full_url:http://gotask.vs/go-uploads/2013-06/ae185df434b93af8bc18ae71229a062d.jpg', 'general', '2013-06-21 01:57:14'),
(13, 16, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-21 01:57:14'),
(14, 17, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-27 00:15:24'),
(15, 18, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-27 00:27:01'),
(16, 18, 1, 'Tarefa foi REMOVIDA com sucesso. ID:18', 'general', '2013-06-27 00:27:05'),
(17, 17, 3, 'Tarefa visualizada por Gustavo Di Calafiori (id:3)', 'general', '2013-06-27 07:42:31'),
(18, 12, 3, 'Tarefa recebeu novo comentario.', 'commented', '2013-06-27 07:43:16'),
(19, 17, 3, 'Tarefa visualizada por Gustavo Di Calafiori (id:3)', 'general', '2013-06-27 07:43:16'),
(20, 17, 3, 'Tarefa recebeu novo arquivo. Link: file_id:2/ full_url:http://wallacesilva.com/projects/taskino/go-uploads/2013-06/89764c4d4dd7a8fc87ae140580bd5f9a.pdf', 'general', '2013-06-27 07:44:05'),
(21, 17, 3, 'Tarefa visualizada por Gustavo Di Calafiori (id:3)', 'general', '2013-06-27 07:44:05'),
(22, 17, 3, 'Tarefa recebeu novo arquivo. Link: file_id:3/ full_url:http://wallacesilva.com/projects/taskino/go-uploads/2013-06/8be6ee771d1c89159fa2901986440437.pdf', 'general', '2013-06-27 07:44:55'),
(23, 17, 3, 'Tarefa visualizada por Gustavo Di Calafiori (id:3)', 'general', '2013-06-27 07:44:56'),
(24, 16, 3, 'Tarefa visualizada por Gustavo Di Calafiori (id:3)', 'general', '2013-06-27 07:45:51'),
(25, 17, 3, 'Tarefa visualizada por Gustavo Di Calafiori (id:3)', 'general', '2013-06-27 11:05:05'),
(26, 6, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-28 20:38:41'),
(27, 3, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-28 20:39:14'),
(28, 17, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-30 21:17:44');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_comments`
--

DROP TABLE IF EXISTS `go_task_comments`;
CREATE TABLE IF NOT EXISTS `go_task_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Extraindo dados da tabela `go_task_comments`
--

INSERT INTO `go_task_comments` (`id`, `task_id`, `subject`, `comment`, `created_by`, `date_added`) VALUES
(1, 3, 'First Comment', 'Wow :D', 1, '2013-06-17 16:48:24'),
(2, 3, 'Second Comment', 'Wow very funny', 1, '2013-06-17 16:48:44'),
(3, 11, 'Criado ', 'Criado sistema mas não foi colocado online, por falta de internet', 1, '2013-06-19 18:41:02'),
(4, 12, 'Disponivel online', 'Arquivos foram colocados online com a ajuda do Leonardo que criou o banco de dados e colocou os arquivos para mim que não tenho acesso ao banco de dados', 1, '2013-06-19 18:42:24'),
(5, 13, 'Removido', 'Botão foi removido hoje(19/06/2013) pela manhã, antes de eu ir almoçar.', 1, '2013-06-19 18:43:36'),
(6, 9, 'Feito mas nao resolvido', 'Criado conforme solicitado, porém não conseguimos resolver o problema de conexão com o banco via phpMyAdmin, como pode ser algo com a conexão via 3g, iremos aguardar a velox para que talvez seja possivel fazer isso.', 1, '2013-06-19 18:50:37'),
(7, 7, 'Adicionado', 'Imagem enviada pelo lucas via email foi adicionada pela manha gologistics da sbm.\r\n\r\nhttp://www.gologistics.com.br/sbm/principal.php\r\n', 1, '2013-06-19 18:51:43'),
(8, 11, 'já adicionado online', 'done com muito sacrificio mas colocamos(eu e Leonardo)', 1, '2013-06-19 14:02:50'),
(9, 3, 'aviso sobre essa alteracao', 'Será corrigido outros items antes que seja feito pois o visual pode complicar no futuro, então irei focar na funcionalidade', 1, '2013-06-19 14:04:40'),
(10, 3, 'Visao futura', 'Essa implementação será realizada somente na versão 2 do goLogistics e goTransfer', 1, '2013-06-19 17:37:46'),
(11, 15, 'Ok', 'Finalizado na parte da manha quando Lucas estava aqui rapidamente com internet.', 1, '2013-06-20 12:54:12'),
(12, 17, 'teste', 'teste', 3, '2013-06-27 07:43:16');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_files`
--

DROP TABLE IF EXISTS `go_task_files`;
CREATE TABLE IF NOT EXISTS `go_task_files` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(11) unsigned NOT NULL,
  `description` varchar(255) NOT NULL COMMENT 'descricao para o arquivo',
  `filename` varchar(255) NOT NULL COMMENT 'nome do arquivo com extensao',
  `file_type` varchar(255) NOT NULL COMMENT 'tipo de arquivo',
  `full_path` varchar(255) NOT NULL COMMENT 'pasta onde foi feito upload',
  `full_url` varchar(255) NOT NULL COMMENT 'url direta para o arquivo',
  `is_image` tinyint(1) NOT NULL COMMENT 'informa se arquivo eh imagem',
  `file_size` varchar(255) NOT NULL COMMENT 'tamanho em kilobytes do arquivo',
  `created_by` int(11) unsigned NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `go_task_files`
--

INSERT INTO `go_task_files` (`id`, `task_id`, `description`, `filename`, `file_type`, `full_path`, `full_url`, `is_image`, `file_size`, `created_by`, `date_added`) VALUES
(1, 16, '', 'ae185df434b93af8bc18ae71229a062d.jpg', 'image/jpeg', '/go-uploads/2013-06/ae185df434b93af8bc18ae71229a062d.jpg', 'http://gotask.vs/go-uploads/2013-06/ae185df434b93af8bc18ae71229a062d.jpg', 1, '38.5', 1, '2013-06-21 01:57:13'),
(2, 17, '', '89764c4d4dd7a8fc87ae140580bd5f9a.pdf', 'application/pdf', '/go-uploads/2013-06/89764c4d4dd7a8fc87ae140580bd5f9a.pdf', 'http://wallacesilva.com/projects/taskino/go-uploads/2013-06/89764c4d4dd7a8fc87ae140580bd5f9a.pdf', 0, '72.08', 3, '2013-06-27 07:44:05'),
(3, 17, '', '8be6ee771d1c89159fa2901986440437.pdf', 'application/pdf', '/go-uploads/2013-06/8be6ee771d1c89159fa2901986440437.pdf', 'http://wallacesilva.com/projects/taskino/go-uploads/2013-06/8be6ee771d1c89159fa2901986440437.pdf', 0, '72.08', 3, '2013-06-27 07:44:55');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_todo`
--

DROP TABLE IF EXISTS `go_task_todo`;
CREATE TABLE IF NOT EXISTS `go_task_todo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
