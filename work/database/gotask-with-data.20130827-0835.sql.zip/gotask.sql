-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tempo de Geração: 
-- Versão do Servidor: 5.5.27
-- Versão do PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `gotask`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_ci_sessions`
--

DROP TABLE IF EXISTS `go_ci_sessions`;
CREATE TABLE IF NOT EXISTS `go_ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `go_ci_sessions`
--

INSERT INTO `go_ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('9f163ed8b13be6526016a788af442b93', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.57 Safari/537.36', 1377602593, 'a:3:{s:12:"taskino_lang";s:10:"portuguese";s:6:"member";a:12:{s:2:"id";s:1:"1";s:10:"company_id";s:1:"1";s:4:"name";s:13:"Wallace Silva";s:5:"email";s:17:"aliga12@gmail.com";s:5:"login";s:7:"aliga12";s:6:"status";s:6:"active";s:16:"language_default";s:10:"portuguese";s:8:"is_admin";s:3:"yes";s:15:"is_admin_master";s:3:"yes";s:14:"activation_key";s:0:"";s:10:"date_added";s:19:"2013-06-10 14:44:15";s:15:"date_last_login";s:19:"2013-08-26 14:43:23";}s:7:"company";a:10:{s:2:"id";s:1:"1";s:4:"name";s:6:"in9web";s:5:"email";s:18:"contato@in9web.com";s:8:"url_logo";s:46:"http://in9web.com/media/images/logo-in9web.png";s:8:"codename";s:6:"in9web";s:11:"folder_name";s:6:"in9web";s:14:"plan_id_active";s:1:"1";s:14:"payment_status";s:9:"confirmed";s:16:"company_activate";N;s:10:"date_added";s:19:"2013-07-30 11:17:09";}}');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_configs`
--

DROP TABLE IF EXISTS `go_configs`;
CREATE TABLE IF NOT EXISTS `go_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `config_name` varchar(255) NOT NULL,
  `config_key` int(255) NOT NULL,
  `config_value` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_members`
--

DROP TABLE IF EXISTS `go_members`;
CREATE TABLE IF NOT EXISTS `go_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(41) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `language_default` varchar(255) NOT NULL DEFAULT 'portuguese' COMMENT 'define traducao padrao para o usuario, english/portuguese',
  `is_admin` enum('yes','no') NOT NULL DEFAULT 'no',
  `is_admin_master` enum('yes','no') NOT NULL DEFAULT 'no' COMMENT 'define se eh o admin da conta que nao pode deixar de ser admin',
  `activation_key` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Extraindo dados da tabela `go_members`
--

INSERT INTO `go_members` (`id`, `company_id`, `name`, `email`, `login`, `password`, `status`, `language_default`, `is_admin`, `is_admin_master`, `activation_key`, `date_added`, `date_last_login`) VALUES
(1, 1, 'Wallace Silva', 'aliga12@gmail.com', 'aliga12', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'active', 'portuguese', 'yes', 'yes', '', '2013-06-10 14:44:15', '2013-08-27 08:25:10'),
(2, 1, 'Gabriel Bruno', 'gabriel@in9web.com', 'gabriel', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'inactive', 'english', 'no', 'no', '', '2013-08-09 16:09:22', NULL),
(4, 2, 'Gustavo Di Calafiori', 'ghcalafiori@gmail.com', 'gustavo', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'active', 'english', 'yes', 'yes', '', '2013-07-05 20:19:32', '2013-08-26 14:42:56'),
(8, 2, 'Wallace Silva', 'aliga12@gmail.com.br', 'aliga12-2', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'active', 'portuguese', 'no', 'no', '', '2013-08-13 00:42:41', '2013-08-26 14:43:13'),
(13, 3, 'Wallace', 'aliga12@gmail.com', 'wallacesilva', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'active', 'portuguese', 'yes', 'yes', '', '2013-08-26 20:55:30', '2013-08-26 20:55:44');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_member_company`
--

DROP TABLE IF EXISTS `go_member_company`;
CREATE TABLE IF NOT EXISTS `go_member_company` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `is_admin` enum('yes','no') NOT NULL DEFAULT 'no',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Extraindo dados da tabela `go_member_company`
--

INSERT INTO `go_member_company` (`id`, `member_id`, `company_id`, `is_admin`, `date_added`) VALUES
(1, 1, 1, 'yes', '2013-08-19 21:17:29'),
(2, 2, 1, 'no', '2013-08-19 21:17:29'),
(3, 4, 2, 'yes', '2013-08-19 21:17:29'),
(4, 1, 2, 'no', '2013-08-19 21:17:29'),
(5, 10, 1, 'no', '2013-08-20 23:48:53'),
(6, 11, 1, 'no', '2013-08-26 10:45:15'),
(7, 12, 1, 'no', '2013-08-26 11:18:55');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_member_options`
--

DROP TABLE IF EXISTS `go_member_options`;
CREATE TABLE IF NOT EXISTS `go_member_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_member_id` int(11) NOT NULL,
  `option_title` varchar(255) NOT NULL,
  `option_key` varchar(255) NOT NULL,
  `option_value` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_projects`
--

DROP TABLE IF EXISTS `go_projects`;
CREATE TABLE IF NOT EXISTS `go_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `total_percent` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `go_projects`
--

INSERT INTO `go_projects` (`id`, `company_id`, `name`, `description`, `total_percent`, `priority`, `created_by`, `date_added`) VALUES
(1, 1, 'Projeto principal usado para testes', 'wow na moral mas ja ta salvando?\r\n', 0, 2, 1, '2013-07-30 14:03:48'),
(2, 1, 'Outro projeto', 'wowow na moral', 0, 2, 1, '2013-08-09 14:30:28'),
(3, 2, 'portfolio sensee', 'o que sera q sera feito', 0, 2, 4, '2013-08-09 17:01:51'),
(4, 3, 'Primeiro projeto', 'wowo', 0, 2, 13, '2013-08-26 20:57:09');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_company`
--

DROP TABLE IF EXISTS `go_taskino_company`;
CREATE TABLE IF NOT EXISTS `go_taskino_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `url_logo` varchar(255) NOT NULL,
  `codename` varchar(255) NOT NULL,
  `folder_name` varchar(255) NOT NULL,
  `plan_id_active` int(11) NOT NULL,
  `payment_status` varchar(255) NOT NULL COMMENT 'pending, confirmed, canceled',
  `company_activate` varchar(255) DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `go_taskino_company`
--

INSERT INTO `go_taskino_company` (`id`, `name`, `email`, `url_logo`, `codename`, `folder_name`, `plan_id_active`, `payment_status`, `company_activate`, `date_added`) VALUES
(1, 'in9web', 'contato@in9web.com', 'http://in9web.com/media/images/logo-in9web.png', 'in9web', 'in9web', 1, 'confirmed', NULL, '2013-07-30 11:17:09'),
(2, 'Sensee', 'agenciasensee@gmail.com', 'http://in9web.com/media/images/logo-i9web.png', 'sensee', 'sensee', 1, 'confirmed', NULL, '2013-08-09 00:00:00'),
(3, 'Virtore', 'aliga12@gmail.com', '', 'Virtore', 'Virtore', 1, 'confirmed', 'LF5481YZNMvycVfX', '2013-08-26 20:55:30');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_company_options`
--

DROP TABLE IF EXISTS `go_taskino_company_options`;
CREATE TABLE IF NOT EXISTS `go_taskino_company_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `option_title` varchar(255) NOT NULL,
  `option_key` varchar(255) NOT NULL,
  `option_value` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_company_payments`
--

DROP TABLE IF EXISTS `go_taskino_company_payments`;
CREATE TABLE IF NOT EXISTS `go_taskino_company_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `plan_id` int(11) NOT NULL,
  `date_requested` datetime NOT NULL COMMENT 'data em que foi solicitado pagamento',
  `staff_member_confirmed_id` int(11) NOT NULL COMMENT 'id do usuario que aprovou pagamento',
  `date_confirmed` datetime NOT NULL COMMENT 'data em que pagamento foi confirmado',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='salvar historico de pagamentos das empresas' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_plans`
--

DROP TABLE IF EXISTS `go_taskino_plans`;
CREATE TABLE IF NOT EXISTS `go_taskino_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` varchar(255) NOT NULL,
  `max_filesize` int(11) NOT NULL COMMENT 'define maximo para upload, em Megabytes/MB',
  `max_tasks` int(11) NOT NULL,
  `max_projects` int(11) NOT NULL,
  `status` varchar(255) NOT NULL COMMENT 'definie se plano: active, inactive',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `go_taskino_plans`
--

INSERT INTO `go_taskino_plans` (`id`, `name`, `description`, `price`, `max_filesize`, `max_tasks`, `max_projects`, `status`, `date_added`) VALUES
(1, 'Free', '', '0', 100, 0, 5, 'active', '2013-07-30 11:20:27');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_staff_member`
--

DROP TABLE IF EXISTS `go_taskino_staff_member`;
CREATE TABLE IF NOT EXISTS `go_taskino_staff_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `is_admin` enum('yes','no') NOT NULL,
  `status` varchar(255) NOT NULL COMMENT 'active, inactive',
  `date_last_login` datetime NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='salva dados da equipe taskino' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_staff_member_options`
--

DROP TABLE IF EXISTS `go_taskino_staff_member_options`;
CREATE TABLE IF NOT EXISTS `go_taskino_staff_member_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_member_id` int(11) NOT NULL COMMENT 'id do membro da equipe taskino',
  `option_title` varchar(255) NOT NULL,
  `option_key` varchar(255) NOT NULL,
  `option_value` text NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_support_faq`
--

DROP TABLE IF EXISTS `go_taskino_support_faq`;
CREATE TABLE IF NOT EXISTS `go_taskino_support_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `faq_question` varchar(255) NOT NULL COMMENT 'pergunta ',
  `faq_answer` text NOT NULL COMMENT 'resposta',
  `support_topic_id` int(11) NOT NULL COMMENT 'id do topico relacionado com a pergunta',
  `author_name` varchar(255) NOT NULL COMMENT 'nome de quem fez a pergunta',
  `author_email` varchar(255) NOT NULL COMMENT 'email de quem fez a pergunta',
  `staff_member_id` int(11) NOT NULL COMMENT 'id do membro da equipe que aprovou pergunta',
  `status` varchar(255) NOT NULL COMMENT 'status da pergunta: active, pending, blocked',
  `date_approved` datetime NOT NULL COMMENT 'data em que foi aprovada',
  `date_added` datetime NOT NULL COMMENT 'data em que foi adicionada',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_taskino_support_topic`
--

DROP TABLE IF EXISTS `go_taskino_support_topic`;
CREATE TABLE IF NOT EXISTS `go_taskino_support_topic` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(255) NOT NULL COMMENT 'status do topico active, inactive',
  `staff_member_id` int(11) NOT NULL COMMENT 'membro do taskino que adicionou o topico',
  `date_added` datetime NOT NULL COMMENT 'data em que foi adicionado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_tasks`
--

DROP TABLE IF EXISTS `go_tasks`;
CREATE TABLE IF NOT EXISTS `go_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `assigned_to` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `privacy_type` enum('public','protected','private') NOT NULL DEFAULT 'public' COMMENT 'public todos veem, protected so com senha, private so quem vai fazer e quem criou',
  `task_folder` varchar(255) NOT NULL DEFAULT 'inbox' COMMENT 'local onde fica as tarefas, inbox, trash, archive',
  `total_percent` int(11) NOT NULL DEFAULT '0' COMMENT 'porcentagem ja realizada da tarefa, valor aproximado',
  `task_due_date` datetime DEFAULT NULL COMMENT 'data em que vence a tarefa, data do prazo',
  `date_finalized` datetime DEFAULT NULL COMMENT 'data em que foi finalizado',
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

--
-- Extraindo dados da tabela `go_tasks`
--

INSERT INTO `go_tasks` (`id`, `project_id`, `company_id`, `name`, `description`, `assigned_to`, `priority`, `status`, `privacy_type`, `task_folder`, `total_percent`, `task_due_date`, `date_finalized`, `created_by`, `date_added`) VALUES
(1, NULL, 1, 'Arquivos de usuarios', 'Arquivos de usuarios', 1, 0, 2, 'private', 'archive', 100, NULL, '2013-06-12 00:00:00', 1, '2013-06-10 20:15:17'),
(5, 1, 1, 'Tarefa teste', 'dsdsds', 1, 4, 2, 'public', 'inbox', 100, NULL, '2013-06-19 14:48:13', 1, '2013-06-11 23:01:04'),
(7, 1, 1, 'Adicionar imagem da embarcação enviado por Lucas', 'Adicionar no banco de dados, criar arquivo para fazer o mesmo pois não foi acessar o phpmyadmin, não possuo acesso de fora da empresa :(', 1, 3, 2, 'public', 'inbox', 100, NULL, '2013-06-19 14:02:09', 1, '2013-06-19 11:15:00'),
(9, 1, 1, 'Instalar e criar conexão VPN para acessar phpMyAdmin', 'Leo me passou arquivo para instalar OpenVPN para conectar ao banco de dados, usando phpMyAdmin. Devo instalar e colocar a pasta no diretorio "config" da aplicação dentro do arquivos de programas do Windows\n\nbaixar arquivo do openvpn \n \nhttp://proxy.cabtur.com.br/vpn/chave/wsilva_21.zip\n', 1, 3, 2, 'public', 'inbox', 100, NULL, '2013-06-19 10:13:18', 1, '2013-06-18 17:04:16'),
(11, 1, 1, 'Criar goLogistics e goTransfer para SBMOffshore', 'Criar goLogistics e goTransfer para SBM.\r\nInserir dados enviados por Lucas para adicionar.\r\nPara agilizar manter as tabelas: (niveis, tiposservico, comunidades, cidades)\r\n\r\nArquivo está em Excel enviado por email por Lucas Ribeiro.', 1, 2, 2, 'public', 'inbox', 100, NULL, '2013-06-19 14:03:05', 1, '2013-06-13 17:28:22'),
(12, 1, 1, 'Colocar versão do goLogistics e goTransfer da SBM online', 'Adicionar a versão criada com os dados inseridos no servidor para ficar disponivel online e via a seguinte URL \r\n\r\nhttp://www.gologistics.com.br/sbm/\r\n\r\nCriar login e senha para Leo Balard e Lucas Ribeiro.', 1, 3, 2, 'public', 'inbox', 100, NULL, '2013-06-14 11:28:04', 1, '2013-06-14 15:50:18'),
(13, 1, 1, 'Remover botão Gerar Planilha de Rooster no SBM', 'Lucas pediu para remover o botão "Gerar Planilha de Rooster" quando abre a página de gerenciamento de passageiros no goLogistics da SBM offshore.\r\n\r\nhttp://www.gologistics.com.br/sbm/', 1, 3, 2, 'public', 'inbox', 100, NULL, '2013-06-19 11:25:10', 1, '2013-06-19 11:07:13'),
(15, 1, 1, 'Corrigir erro de email no sbmoffshore', 'encontrei um erro de email quando realizava alterações na versão 2.0 goLogistics, adicionar correções na versão do sbm funcionando atualmente online.\r\n\r\nAguardar Lucas com internet pra subir alterações', 1, 2, 2, 'public', 'inbox', 100, NULL, '2013-06-20 12:54:22', 1, '2013-06-20 10:09:11'),
(17, 1, 1, 'Testando para Gustavo', 'wow', 2, 3, 1, 'public', 'inbox', 0, '0000-00-00 00:00:00', NULL, 1, '2013-06-27 00:15:24'),
(22, 1, 1, 'Continuar Social Mamy', 'Continuar de onde foi feito o Social Mamy.', 1, 3, 1, 'public', 'inbox', 0, '2013-07-31 00:00:00', NULL, 1, '2013-07-01 16:57:53'),
(23, 1, 1, 'Criar sistema basico para o Guia Local', 'Projeto sendo realizado com o Gabriel, ', 1, 3, 1, 'public', 'inbox', 0, '2013-07-31 00:00:00', NULL, 1, '2013-07-01 17:01:33'),
(24, 1, 1, 'Alterar privacidade da tarefa', 'Adicionar campo que controle quem pode ver a tarefa, podendo ser \r\npublic - todos veem\r\nprotected - somente com senha e quem criou ve\r\nprivate - so ve quem vai fazer e quem criou', 1, 3, 1, 'public', 'inbox', 0, '2013-07-17 00:00:00', NULL, 1, '2013-07-01 17:03:01'),
(25, 1, 1, 'Terminar RC Andaimes', 'Terminar alteracoes solicitadas pela rc andaimes e a agencia Chave', 1, 2, 2, 'public', 'inbox', 100, '2013-07-17 00:00:00', '2013-07-02 23:19:11', 1, '2013-07-01 17:04:14'),
(26, 1, 1, 'Criar sistema de blog  - postir', 'Criar sistema de blog mais simples que wordpress e layout maneiro tipo o Ghost\r\n\r\nVeja link do site do ghost que usar editor markdown\r\nhttp://tryghost.org/index.html\r\n', 1, 4, 1, 'public', 'inbox', 0, '2013-11-29 00:00:00', NULL, 1, '2013-07-01 17:06:46'),
(27, 1, 1, 'convidar membros para equipe', 'usar metodologia de equipe para facilitar e acabar com membros, pois dai o membro pode participar de varias equipes em varias empresas', 1, 3, 1, 'public', 'inbox', 0, '2013-08-09 00:00:00', NULL, 1, '2013-07-05 10:08:51'),
(28, 1, 1, 'Adicionar tradução e icone no topo', 'adicionar icone de tradução e criar arquivos para tradução em ingles e portugues', 1, 3, 2, 'public', 'inbox', 100, '2013-07-12 00:00:00', '2013-07-05 21:49:25', 1, '2013-07-05 10:10:02'),
(29, 1, 1, 'Melhorar area de membro/profile', 'melhorar onde o usuario pode mudar seu perfil e dados para ficar algo mais legal e bonito,\r\ntipo\r\n\r\nadd foto\r\nadd facebook, twitter\r\n\r\npermitir exibir perfil public que dai pode exibir ultimos tweets, foto, blog/rsss e afins', 1, 4, 1, 'public', 'inbox', 0, '2013-07-19 00:00:00', NULL, 1, '2013-07-05 10:13:31'),
(30, 1, 1, 'Criar planos para cada conta', 'criar planos para limitar quanto pode ser usado para poder vender o sistema', 1, 3, 1, 'public', 'inbox', 0, '2013-07-12 00:00:00', NULL, 1, '2013-07-05 10:16:04'),
(31, 1, 1, 'Adicionar link externo para download de arquivos', 'possibilitar na hora do download fazer download de arquivos externos em outros servidores como dropbox, 4shared e afins, \r\n\r\nlembrar de colocar notificacao na hora do download informando que o arquivo esta em um servidor externo', 1, 3, 1, 'public', 'inbox', 0, '2013-07-18 00:00:00', NULL, 1, '2013-07-05 11:02:38'),
(32, 1, 1, 'Criar layout para novos cadastros', 'criar layout para entrada de novos clientes e exibir os planos permitidos para as pessoa usarem', 1, 4, 1, 'public', 'inbox', 0, '2013-07-31 00:00:00', NULL, 1, '2013-07-05 13:04:44'),
(39, 1, 1, 'Criar sistema de caixas para tarefa', 'Sistema permite sempre cadastrar tarefas e deixala na inbox no qual sera exibido no sistema, podem ao excluir, ele coloca as tarefas na caixa trash que depois de alguns dias é removida automaticamente do sistema, e prevejo que pode ter outra caixa a archive que salva tarefas nao usadas no momento.', 1, 3, 2, 'public', 'trash', 100, '2013-07-17 00:00:00', '2013-07-11 01:33:30', 1, '2013-07-05 19:22:29'),
(40, 1, 1, 'Adicionar sistema de busca por tarefas', 'adicionar inicialmente sistema de busca por nome de tarefas, depois melhorar proposta', 1, 3, 1, 'public', 'inbox', 0, '2013-07-09 00:00:00', NULL, 1, '2013-07-05 20:48:46'),
(44, 1, 1, 'Campaign 1', 'sdsd\r\nsd\r\nsd\r\ns\r\nd\r\ns', 1, 5, 1, 'public', 'inbox', 0, '2013-07-19 00:00:00', NULL, 1, '2013-07-05 22:16:50'),
(45, 1, 1, 'Sistema de notificações', 'adicionar sistema de notificações com tiposde notificacoes, \r\npode ser usado em categorias, tendo 2 iniciais ''alerts'', ''notifications''\r\nalerts = notifica via alert,um caixa que sobe do rodape\r\nnotifications, fica no todo da tela ate confirmar que leu e dai remove/oculta\r\n\r\nos tipos serão para definir a cor da notificação, verde, azul, vermelho e por ai vai.\r\n\r\n', 1, 3, 1, 'public', 'inbox', 0, '2013-07-19 00:00:00', NULL, 1, '2013-07-13 16:43:28'),
(46, 1, 1, 'Sistema de update ', 'mudar metologia de arquivos para facilitar update de arquivos e banco de dados', 1, 3, 1, 'public', 'inbox', 0, '2013-07-24 00:00:00', NULL, 1, '2013-07-14 03:32:07'),
(47, 2, 1, 'tarefa para outro projeto', 'irado wowow', 1, 3, 1, 'public', 'inbox', 19, '2013-08-16 16:17:47', NULL, 1, '2013-08-09 16:17:47'),
(48, 3, 2, 'Conferir com Wallace ', 'analisar o que falta pra temrinar', 4, 3, 1, 'public', 'inbox', 70, '2013-08-16 17:02:27', NULL, 4, '2013-08-09 17:02:27'),
(49, 4, 3, 'primeira tarefa do primeito proj', 'wowow', 13, 3, 1, 'public', 'inbox', 0, '2013-08-28 00:00:00', NULL, 13, '2013-08-26 20:57:33');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_tasks_log`
--

DROP TABLE IF EXISTS `go_tasks_log`;
CREATE TABLE IF NOT EXISTS `go_tasks_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `description` text NOT NULL,
  `category_log` varchar(255) NOT NULL COMMENT 'category/tipo de log general, created, assigned_to, commented',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=331 ;

--
-- Extraindo dados da tabela `go_tasks_log`
--

INSERT INTO `go_tasks_log` (`id`, `task_id`, `member_id`, `description`, `category_log`, `date_added`) VALUES
(1, 3, 1, 'Tarefa foi atualizada com sucesso', 'general', '2013-06-19 17:27:16'),
(2, 3, 1, 'Tarefa foi atualizada com sucesso', 'general', '2013-06-19 17:27:40'),
(3, 10, 1, 'Tarefa recebeu novo comentario.', 'commented', '2013-06-19 17:37:46'),
(4, 3, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-19 17:44:03'),
(5, 15, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-20 10:09:11'),
(6, 15, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-20 12:53:35'),
(7, 11, 1, 'Tarefa recebeu novo comentario.', 'commented', '2013-06-20 12:54:12'),
(8, 15, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-20 12:54:12'),
(9, 15, 1, 'Tarefa foi finalizada em 2013-06-20 12:54:22', 'finalized', '2013-06-20 12:54:22'),
(10, 16, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-20 15:33:14'),
(11, 16, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-21 01:56:58'),
(12, 16, 1, 'Tarefa recebeu novo arquivo. Link: file_id:1/ full_url:http://gotask.vs/go-uploads/2013-06/ae185df434b93af8bc18ae71229a062d.jpg', 'general', '2013-06-21 01:57:14'),
(13, 16, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-21 01:57:14'),
(14, 17, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-27 00:15:24'),
(15, 18, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-27 11:33:31'),
(16, 19, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-27 11:40:40'),
(17, 19, 1, 'Tarefa foi REMOVIDA com sucesso. ID:19', 'general', '2013-06-27 11:41:23'),
(18, 18, 1, 'Tarefa foi REMOVIDA com sucesso. ID:18', 'general', '2013-06-27 11:41:30'),
(19, 20, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-27 11:41:43'),
(20, 20, 1, 'Tarefa foi REMOVIDA com sucesso. ID:20', 'general', '2013-06-27 11:42:24'),
(21, 21, 1, 'Tarefa foi criada com sucesso', 'created', '2013-06-27 11:42:35'),
(22, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:22:20'),
(23, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:25:26'),
(24, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:26:22'),
(25, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:26:33'),
(26, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:27:19'),
(27, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:27:26'),
(28, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:27:32'),
(29, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:28:06'),
(30, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:28:57'),
(31, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:29:02'),
(32, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:29:30'),
(33, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:29:39'),
(34, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:30:15'),
(35, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:30:38'),
(36, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:30:51'),
(37, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:31:17'),
(38, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:32:51'),
(39, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:33:55'),
(40, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:35:15'),
(41, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:35:26'),
(42, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:35:56'),
(43, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:36:29'),
(44, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:36:38'),
(45, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:36:51'),
(46, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:37:08'),
(47, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:37:22'),
(48, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:37:33'),
(49, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:39:17'),
(50, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:46:44'),
(51, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:47:02'),
(52, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:47:24'),
(53, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:47:40'),
(54, 13, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 16:47:52'),
(55, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 17:23:02'),
(56, 21, 1, 'Tarefa teve a percentagem alterada para 53', 'general', '2013-06-27 17:23:13'),
(57, 21, 1, 'Tarefa teve a percentagem alterada para 53', 'general', '2013-06-27 17:23:35'),
(58, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-06-27 17:30:12'),
(59, 21, 1, 'Tarefa teve a percentagem alterada para 37', 'general', '2013-06-27 17:30:20'),
(60, 21, 1, 'Tarefa teve a percentagem alterada para 58', 'general', '2013-06-27 17:30:57'),
(61, 21, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-01 16:53:56'),
(62, 3, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-01 16:54:15'),
(63, 21, 1, 'Tarefa foi REMOVIDA com sucesso. ID:21', 'general', '2013-07-01 16:56:44'),
(64, 16, 1, 'Tarefa foi REMOVIDA com sucesso. ID:16', 'general', '2013-07-01 16:56:49'),
(65, 6, 1, 'Tarefa foi REMOVIDA com sucesso. ID:6', 'general', '2013-07-01 16:56:52'),
(66, 14, 1, 'Tarefa foi REMOVIDA com sucesso. ID:14', 'general', '2013-07-01 16:56:54'),
(67, 8, 1, 'Tarefa foi REMOVIDA com sucesso. ID:8', 'general', '2013-07-01 16:57:02'),
(68, 3, 1, 'Tarefa foi REMOVIDA com sucesso. ID:3', 'general', '2013-07-01 16:57:04'),
(69, 22, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-01 16:57:53'),
(70, 23, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-01 17:01:33'),
(71, 24, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-01 17:03:01'),
(72, 25, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-01 17:04:14'),
(73, 25, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-01 17:04:16'),
(74, 12, 1, 'Tarefa recebeu novo comentario.', 'commented', '2013-07-01 17:04:53'),
(75, 25, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-01 17:04:53'),
(76, 26, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-01 17:06:46'),
(77, 26, 1, 'Tarefa foi atualizada com sucesso', 'general', '2013-07-01 17:07:17'),
(78, 25, 1, 'Tarefa foi finalizada em 2013-07-02 23:19:11', 'finalized', '2013-07-02 23:19:11'),
(79, 24, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-04 20:39:05'),
(80, 24, 1, 'Tarefa recebeu novo arquivo. Link: file_id:2/ full_url:http://localhost/teste/taskino/go-uploads/2013-07/e304251b06200d86d37293691e8fe3fc.jpg', 'general', '2013-07-04 20:39:14'),
(81, 24, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-04 20:39:14'),
(82, 24, 1, 'Tarefa recebeu novo arquivo. Link: file_id:3/ full_url:http://localhost/teste/taskino/go-uploads/2013-07/39586a91a421d7df36defd8ef3838864.png', 'general', '2013-07-04 20:39:25'),
(83, 24, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-04 20:39:25'),
(84, 27, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 10:08:51'),
(85, 28, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 10:10:02'),
(86, 29, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 10:13:31'),
(87, 30, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 10:16:04'),
(88, 31, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 11:02:38'),
(89, 32, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 13:04:44'),
(90, 33, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 19:05:27'),
(91, 33, 1, 'Usuario Wallace Silva[1] notificado da tarefa testnado smtp[33] por email', 'general', '2013-07-05 19:05:28'),
(92, 34, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 19:09:32'),
(93, 34, 1, 'Usuario Wallace Silva[1] notificado da tarefa testnado smtp[34] por email', 'general', '2013-07-05 19:09:32'),
(94, 35, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 19:10:02'),
(95, 35, 1, 'Usuario Wallace Silva[1] notificado da tarefa Campaign 1[35] por email', 'general', '2013-07-05 19:10:02'),
(96, 36, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 19:11:36'),
(97, 36, 1, 'Usuario Wallace Silva[1] notificado da tarefa Campaign 1[36] por email', 'general', '2013-07-05 19:11:36'),
(98, 37, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 19:12:44'),
(99, 37, 1, 'Usuario Wallace Silva[1] notificado da tarefa Campaign 1[37] por email', 'general', '2013-07-05 19:12:44'),
(100, 37, 1, 'Tarefa foi REMOVIDA com sucesso. ID:37', 'general', '2013-07-05 19:16:21'),
(101, 36, 1, 'Tarefa foi REMOVIDA com sucesso. ID:36', 'general', '2013-07-05 19:16:22'),
(102, 35, 1, 'Tarefa foi REMOVIDA com sucesso. ID:35', 'general', '2013-07-05 19:16:23'),
(103, 34, 1, 'Tarefa foi REMOVIDA com sucesso. ID:34', 'general', '2013-07-05 19:16:25'),
(104, 33, 1, 'Tarefa foi REMOVIDA com sucesso. ID:33', 'general', '2013-07-05 19:16:26'),
(105, 38, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 19:17:04'),
(106, 38, 1, 'Usuario Wallace Silva[1] notificado da tarefa Campaign 1[38] por email', 'general', '2013-07-05 19:17:04'),
(107, 39, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 19:22:29'),
(108, 38, 1, 'Tarefa foi REMOVIDA com sucesso. ID:38', 'general', '2013-07-05 19:22:35'),
(109, 39, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-05 20:22:06'),
(110, 39, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-05 20:22:40'),
(111, 39, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-05 20:37:15'),
(112, 40, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 20:48:46'),
(113, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:48:36'),
(114, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:48:36'),
(115, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:48:36'),
(116, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:48:36'),
(117, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:48:36'),
(118, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:48:36'),
(119, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:48:36'),
(120, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:48:36'),
(121, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:48:36'),
(122, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:48:36'),
(123, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:48:36'),
(124, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:48:36'),
(125, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:48:36'),
(126, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:48:36'),
(127, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:48:36'),
(128, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:48:36'),
(129, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:48:36'),
(130, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:48:36'),
(131, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:48:36'),
(132, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:48:36'),
(133, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:49:02'),
(134, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:49:02'),
(135, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:49:02'),
(136, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:49:02'),
(137, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:49:02'),
(138, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:49:02'),
(139, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:49:02'),
(140, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:49:02'),
(141, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:49:02'),
(142, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:49:02'),
(143, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:49:02'),
(144, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:49:02'),
(145, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:49:02'),
(146, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:49:02'),
(147, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:49:03'),
(148, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:49:03'),
(149, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:49:03'),
(150, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:49:03'),
(151, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:49:03'),
(152, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:49:03'),
(153, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:49:03'),
(154, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:49:03'),
(155, 1, 1, 'Error language on _gettxt:msg_confirm_task_remove', 'general', '2013-07-05 21:49:03'),
(156, 1, 1, 'Error language on _gettxt:msg_confirm_task_finalize', 'general', '2013-07-05 21:49:03'),
(157, 28, 1, 'Tarefa foi finalizada em 2013-07-05 21:49:25', 'finalized', '2013-07-05 21:49:25'),
(158, 41, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 21:59:25'),
(159, 41, 1, 'Tarefa foi REMOVIDA com sucesso. ID:41', 'general', '2013-07-05 21:59:29'),
(160, 42, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 22:00:34'),
(161, 42, 1, 'Tarefa foi REMOVIDA com sucesso. ID:42', 'general', '2013-07-05 22:00:38'),
(162, 43, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 22:14:31'),
(163, 43, 1, 'Tarefa foi REMOVIDA com sucesso. ID:43', 'general', '2013-07-05 22:15:43'),
(164, 44, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-05 22:16:50'),
(165, 39, 1, 'Tarefa foi finalizada em 2013-07-11 01:33:30', 'finalized', '2013-07-11 01:33:30'),
(166, 39, 1, 'Tarefa foi REMOVIDA com sucesso. ID:39', 'general', '2013-07-11 01:35:38'),
(167, 45, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-13 16:43:28'),
(168, 46, 1, 'Tarefa foi criada com sucesso', 'created', '2013-07-14 03:32:08'),
(169, 1, NULL, 'Error language on _gettxt:password', 'general', '2013-07-16 13:44:58'),
(170, 1, NULL, 'Error language on _gettxt:password', 'general', '2013-07-16 13:44:58'),
(171, 1, NULL, 'Error language on _gettxt:password_confirm', 'general', '2013-07-16 13:44:58'),
(172, 1, NULL, 'Error language on _gettxt:password_confirm', 'general', '2013-07-16 13:44:58'),
(173, 1, NULL, 'Error language on _gettxt:save', 'general', '2013-07-16 13:44:58'),
(174, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-18 13:31:54'),
(175, 46, 1, 'Tarefa recebeu novo arquivo. Link: file_id:4/ full_url:http://localhost/teste/taskino/go-uploads/2013-07/c1203bd3e1436d033c6659a816a96ec4.jpg', 'general', '2013-07-18 13:34:33'),
(176, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-18 13:34:33'),
(177, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-18 13:36:18'),
(178, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-18 13:36:27'),
(179, 46, 1, 'Tarefa recebeu novo arquivo. Link: file_id:5/ full_url:http://localhost/teste/taskino/taskino-uploads/2013-07/5a5aae36bf525e210cc98e424268dbad.jpg', 'general', '2013-07-18 13:36:46'),
(180, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-18 13:36:47'),
(181, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-18 13:36:54'),
(182, 46, 1, 'Tarefa recebeu novo arquivo. Link: file_id:6/ full_url:http://localhost/teste/taskino/taskino-uploads/2013-07/6c1279909a500c29b0ba58b49ba86eb6.jpg', 'general', '2013-07-18 13:37:17'),
(183, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-18 13:37:18'),
(184, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-18 13:37:20'),
(185, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-18 13:37:21'),
(186, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-18 13:37:34'),
(187, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-19 18:28:45'),
(188, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-29 16:12:40'),
(189, 45, 1, 'Tarefa recebeu novo arquivo. Link: file_id:4/ full_url:http://taskino.vs/taskino-uploads/taskino2013-07/db7dfe550663651773712cf3bbb3e609.jpg', 'general', '2013-07-29 16:12:50'),
(190, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-29 16:12:50'),
(191, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-29 16:13:50'),
(192, 45, 1, 'Tarefa recebeu novo arquivo. Link: file_id:5/ full_url:http://taskino.vs/taskino-uploads/taskino/2013-07/ba13c8497a67952141d02a503acdb73e.jpg', 'general', '2013-07-29 16:14:02'),
(193, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-29 16:14:02'),
(194, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-29 16:14:10'),
(195, 45, 1, 'Tarefa recebeu novo arquivo. Link: file_id:6/ full_url:http://taskino.vs/taskino-uploads/taskino/2013-07/02531bf2bebbbee07ed1f78a1a596df9.jpg', 'general', '2013-07-29 16:14:23'),
(196, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-29 16:14:23'),
(197, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-29 16:14:26'),
(198, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-29 16:14:27'),
(199, 45, 1, 'Tarefa recebeu novo arquivo. Link: file_id:7/ full_url:http://taskino.vs/taskino-uploads/taskino/2013-07/9c8a10a18efa3f8f68e6acbd37ffe961.jpg', 'general', '2013-07-29 16:16:41'),
(200, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-29 16:17:00'),
(201, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-29 16:17:07'),
(202, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-29 16:17:13'),
(203, 45, 1, 'Tarefa recebeu novo arquivo. Link: file_id:8/ full_url:http://taskino.vs/taskino-uploads/taskino/2013-07/937849b5f1af490bf0c613a85e0c5a8b.jpg', 'general', '2013-07-29 16:17:19'),
(204, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-29 16:17:22'),
(205, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-29 16:17:27'),
(206, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 08:14:07'),
(207, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 08:14:26'),
(208, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 08:14:37'),
(209, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 08:14:59'),
(210, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 08:15:25'),
(211, 46, 1, 'Tarefa recebeu novo arquivo. Link: file_id:/ full_url:', 'general', '2013-07-30 08:38:34'),
(212, 46, 1, 'Tarefa recebeu novo arquivo. Link: file_id:/ full_url:', 'general', '2013-07-30 08:42:39'),
(213, 46, 1, 'Tarefa recebeu novo arquivo. Link: file_id:/ full_url:', 'general', '2013-07-30 08:43:36'),
(214, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 08:56:03'),
(215, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 08:56:07'),
(216, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 09:29:04'),
(217, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 09:29:14'),
(218, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 09:29:17'),
(219, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 09:29:39'),
(220, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 18:40:57'),
(221, 46, 1, 'Tarefa recebeu novo arquivo. Link: file_id:9/ full_url:http://taskino.vs/taskino-uploads/taskino/2013-07/ffb4bfc3e423e20e67c96fef33541398.jpg', 'general', '2013-07-30 18:41:03'),
(222, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 18:41:04'),
(223, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 18:44:05'),
(224, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 18:45:34'),
(225, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 18:45:46'),
(226, 46, 1, 'Tarefa recebeu novo arquivo. Link: file_id:10/ full_url:http://taskino.vs/taskino-uploads/taskino/2013-07/ff92a5a047808d57ee9817e7a943de38.png', 'general', '2013-07-30 18:46:21'),
(227, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 18:46:21'),
(228, 46, 1, 'Tarefa recebeu novo arquivo. Link: file_id:11/ full_url:http://taskino.vs/taskino-uploads/taskino/2013-07/911a8bff8f8dc16c0d8a14b66ff0a44f.zip', 'general', '2013-07-30 18:47:44'),
(229, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 18:47:44'),
(230, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-07-30 18:57:00'),
(231, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-06 18:38:27'),
(232, 46, 1, 'Tarefa foi REMOVIDA com sucesso. ID:46', 'general', '2013-08-06 18:59:22'),
(233, 46, 1, 'Tarefa foi REMOVIDA com sucesso. ID:46', 'general', '2013-08-06 19:01:26'),
(234, 46, 1, 'Tarefa foi REMOVIDA com sucesso. ID:46', 'general', '2013-08-06 19:03:40'),
(235, 46, 1, 'Tarefa foi REMOVIDA com sucesso. ID:46', 'general', '2013-08-06 19:14:49'),
(236, 46, 1, 'Tarefa foi REMOVIDA com sucesso. ID:46', 'general', '2013-08-06 19:16:18'),
(237, 46, 1, 'Tarefa foi REMOVIDA com sucesso. ID:46', 'general', '2013-08-06 19:17:07'),
(238, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-06 19:19:01'),
(239, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:46:55'),
(240, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:52:55'),
(241, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:53:09'),
(242, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:54:24'),
(243, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:54:42'),
(244, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:54:46'),
(245, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:56:02'),
(246, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:56:18'),
(247, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:56:27'),
(248, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:56:41'),
(249, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:56:44'),
(250, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:57:03'),
(251, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:57:17'),
(252, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:57:25'),
(253, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:57:35'),
(254, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:57:43'),
(255, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 08:57:52'),
(256, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 09:01:06'),
(257, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 09:01:44'),
(258, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 09:01:53'),
(259, 45, 1, 'Tarefa recebeu novo arquivo. Link: file_id:12/ full_url:http://taskino.vs/taskino-uploads/taskino/2013-08/e3567e609a4f6fb3c44d64014eff0619.jpg', 'general', '2013-08-07 09:04:13'),
(260, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 09:04:13'),
(261, 45, 1, 'Tarefa recebeu novo arquivo. Link: file_id:13/ full_url:http://taskino.vs/taskino-uploads/taskino/2013-08/42411590e56938b890e9c80a4c5201b5.jpg', 'general', '2013-08-07 09:06:35'),
(262, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 09:06:35'),
(263, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 09:06:52'),
(264, 45, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 09:06:53'),
(265, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 17:24:16'),
(266, 13, 1, 'Tarefa recebeu novo comentario.', 'commented', '2013-08-07 17:24:33'),
(267, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 17:24:34'),
(268, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 18:43:44'),
(269, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 18:51:32'),
(270, 46, 1, 'Tarefa recebeu novo arquivo. Link: file_id:14/ full_url:http://taskino.vs/taskino-uploads/taskino/2013-08/df443f6adbb158fb52aa63bf3389db76.jpg', 'general', '2013-08-07 18:51:39'),
(271, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 18:51:40'),
(272, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 18:52:23'),
(273, 46, 1, 'Tarefa recebeu novo arquivo. Link: file_id:15/ full_url:http://taskino.vs/taskino-uploads/taskino/2013-08/384b2225cf1bd410970d88ff063ddab1.jpg', 'general', '2013-08-07 18:52:28'),
(274, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 18:52:31'),
(275, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 18:55:19'),
(276, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 18:55:22'),
(277, 46, 1, 'Tarefa recebeu novo arquivo. Link: file_id:16/ full_url:http://taskino.vs/taskino-uploads/taskino/2013-08/53a814f647bc7eade306a046574d1c28.jpg', 'general', '2013-08-07 18:55:27'),
(278, 46, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-07 18:55:32'),
(279, 47, 1, 'Tarefa foi criada com sucesso', 'created', '2013-08-09 16:17:47'),
(280, 47, 1, 'Tarefa foi atualizada com sucesso', 'general', '2013-08-09 16:18:05'),
(281, 47, 1, 'Tarefa foi atualizada com sucesso', 'general', '2013-08-09 16:19:19'),
(282, 47, 1, 'Tarefa foi atualizada com sucesso', 'general', '2013-08-09 16:19:34'),
(283, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:39:08'),
(284, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:39:34'),
(285, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:39:56'),
(286, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:40:52'),
(287, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:41:41'),
(288, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:41:57'),
(289, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:44:52'),
(290, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:45:03'),
(291, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:45:19'),
(292, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:46:06'),
(293, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:46:26'),
(294, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:46:29'),
(295, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:46:45'),
(296, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:47:00'),
(297, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:47:09'),
(298, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:47:46'),
(299, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:49:17'),
(300, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:49:28'),
(301, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:49:36'),
(302, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:49:43'),
(303, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:49:46'),
(304, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:49:53'),
(305, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:49:57'),
(306, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:50:01'),
(307, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:50:34'),
(308, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:50:47'),
(309, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:50:56'),
(310, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:51:14'),
(311, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:51:28'),
(312, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:51:38'),
(313, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:52:02'),
(314, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:52:43'),
(315, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:52:50'),
(316, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:53:06'),
(317, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-09 16:55:28'),
(318, 48, 4, 'Tarefa foi criada com sucesso', 'created', '2013-08-09 17:02:27'),
(319, 48, 4, 'Tarefa foi atualizada com sucesso', 'general', '2013-08-09 17:02:39'),
(320, 48, 4, 'Tarefa visualizada por Gustavo Di Calafiori (id:4)', 'general', '2013-08-12 10:41:53'),
(321, 47, 1, 'Tarefa visualizada por Wallace Silva (id:1)', 'general', '2013-08-12 15:12:21'),
(322, 47, 1, 'Tarefa foi encaminhada para Gabriel Bruno (id:2)', 'assigned_to', '2013-08-12 23:23:22'),
(323, 47, 1, 'Tarefa foi encaminhada para Wallace Silva (id:1)', 'assigned_to', '2013-08-12 23:23:30'),
(324, 47, 1, 'Tarefa foi encaminhada para Gabriel Bruno (id:2)', 'assigned_to', '2013-08-12 23:26:58'),
(325, 47, 1, 'Tarefa foi encaminhada para Wallace Silva (id:1)', 'assigned_to', '2013-08-12 23:27:12'),
(326, 5, 1, 'Tarefa foi encaminhada para Wallace Silva (id:1)', 'assigned_to', '2013-08-13 00:03:08'),
(327, 17, 1, 'Tarefa foi encaminhada para Gabriel Bruno (id:2)', 'assigned_to', '2013-08-13 00:05:27'),
(328, 47, 1, 'Tarefa recebeu novo arquivo. Link: file_id:17/ full_url:http://taskino.vs/taskino-uploads/taskino/2013-08/0d3a0c9706978cae142fa43bc9a49b50.png', 'general', '2013-08-26 13:41:19'),
(329, 47, 1, 'Tarefa recebeu novo arquivo. Link: file_id:18/ full_url:http://taskino.vs/taskino-uploads/in9web/2013-08/9ed9d6de10a51c2603b4fcd75198403d.png', 'general', '2013-08-26 13:52:21'),
(330, 49, 13, 'Tarefa foi criada com sucesso', 'created', '2013-08-26 20:57:33');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_comments`
--

DROP TABLE IF EXISTS `go_task_comments`;
CREATE TABLE IF NOT EXISTS `go_task_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Extraindo dados da tabela `go_task_comments`
--

INSERT INTO `go_task_comments` (`id`, `task_id`, `subject`, `comment`, `created_by`, `date_added`) VALUES
(1, 3, 'First Comment', 'Wow :D', 1, '2013-06-17 16:48:24'),
(2, 3, 'Second Comment', 'Wow very funny', 1, '2013-06-17 16:48:44'),
(3, 11, 'Criado ', 'Criado sistema mas não foi colocado online, por falta de internet', 1, '2013-06-19 18:41:02'),
(4, 12, 'Disponivel online', 'Arquivos foram colocados online com a ajuda do Leonardo que criou o banco de dados e colocou os arquivos para mim que não tenho acesso ao banco de dados', 1, '2013-06-19 18:42:24'),
(5, 13, 'Removido', 'Botão foi removido hoje(19/06/2013) pela manhã, antes de eu ir almoçar.', 1, '2013-06-19 18:43:36'),
(6, 9, 'Feito mas nao resolvido', 'Criado conforme solicitado, porém não conseguimos resolver o problema de conexão com o banco via phpMyAdmin, como pode ser algo com a conexão via 3g, iremos aguardar a velox para que talvez seja possivel fazer isso.', 1, '2013-06-19 18:50:37'),
(7, 7, 'Adicionado', 'Imagem enviada pelo lucas via email foi adicionada pela manha gologistics da sbm.\r\n\r\nhttp://www.gologistics.com.br/sbm/principal.php\r\n', 1, '2013-06-19 18:51:43'),
(8, 11, 'já adicionado online', 'done com muito sacrificio mas colocamos(eu e Leonardo)', 1, '2013-06-19 14:02:50'),
(9, 3, 'aviso sobre essa alteracao', 'Será corrigido outros items antes que seja feito pois o visual pode complicar no futuro, então irei focar na funcionalidade', 1, '2013-06-19 14:04:40'),
(10, 3, 'Visao futura', 'Essa implementação será realizada somente na versão 2 do goLogistics e goTransfer', 1, '2013-06-19 17:37:46'),
(11, 15, 'Ok', 'Finalizado na parte da manha quando Lucas estava aqui rapidamente com internet.', 1, '2013-06-20 12:54:12'),
(12, 25, 'Cobraram agilidade', 'Adil me ligou hoje cobrando agilidade pois o cliente ta falando no ouvido dele.', 1, '2013-07-01 17:04:53'),
(13, 46, 'testing', 'new comment wow', 1, '2013-08-07 17:24:33');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_files`
--

DROP TABLE IF EXISTS `go_task_files`;
CREATE TABLE IF NOT EXISTS `go_task_files` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(11) unsigned NOT NULL,
  `company_id` int(11) NOT NULL COMMENT 'id da empres ao qual pertence o arquivo, usado acelerar a consulta ',
  `description` varchar(255) NOT NULL COMMENT 'descricao para o arquivo',
  `filename` varchar(255) NOT NULL COMMENT 'nome do arquivo com extensao',
  `file_type` varchar(255) NOT NULL COMMENT 'tipo de arquivo',
  `full_path` varchar(255) NOT NULL COMMENT 'pasta onde foi feito upload',
  `full_url` varchar(255) NOT NULL COMMENT 'url direta para o arquivo',
  `is_image` tinyint(1) NOT NULL COMMENT 'informa se arquivo eh imagem',
  `file_size` varchar(255) NOT NULL COMMENT 'tamanho em kilobytes do arquivo',
  `hosted_on` varchar(255) NOT NULL DEFAULT 'taskino' COMMENT 'local onde esta o arquivo, taskino=servidor local, senao nome da empresa',
  `created_by` int(11) unsigned NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Extraindo dados da tabela `go_task_files`
--

INSERT INTO `go_task_files` (`id`, `task_id`, `company_id`, `description`, `filename`, `file_type`, `full_path`, `full_url`, `is_image`, `file_size`, `hosted_on`, `created_by`, `date_added`) VALUES
(1, 16, 1, '', 'ae185df434b93af8bc18ae71229a062d.jpg', 'image/jpeg', '/taskino-uploads/taskino/2013-06/ae185df434b93af8bc18ae71229a062d.jpg', 'http://taskino.vs/taskino-uploads/taskino/2013-06/ae185df434b93af8bc18ae71229a062d.jpg', 1, '38.5', 'taskino', 1, '2013-06-21 01:57:13'),
(2, 24, 1, '', 'e304251b06200d86d37293691e8fe3fc.jpg', 'image/jpeg', '/taskino-uploads/taskino/2013-07/e304251b06200d86d37293691e8fe3fc.jpg', 'http://taskino.vs/taskino-uploads/taskino/2013-07/e304251b06200d86d37293691e8fe3fc.jpg', 1, '38.5', 'taskino', 1, '2013-07-04 20:39:13'),
(3, 24, 1, '', '39586a91a421d7df36defd8ef3838864.png', 'image/png', '/taskino-uploads/taskino/2013-07/39586a91a421d7df36defd8ef3838864.png', 'http://taskino.vs/taskino-uploads/taskino/2013-07/39586a91a421d7df36defd8ef3838864.png', 1, '288.58', 'taskino', 1, '2013-07-04 20:39:24'),
(9, 46, 1, '', 'ffb4bfc3e423e20e67c96fef33541398.jpg', 'image/jpeg', '/taskino-uploads/taskino/2013-07/ffb4bfc3e423e20e67c96fef33541398.jpg', 'http://taskino.vs/taskino-uploads/taskino/2013-07/ffb4bfc3e423e20e67c96fef33541398.jpg', 1, '8.7', 'taskino', 1, '2013-07-30 18:41:03'),
(10, 46, 1, '', 'ff92a5a047808d57ee9817e7a943de38.png', 'image/png', '/taskino-uploads/taskino/2013-07/ff92a5a047808d57ee9817e7a943de38.png', 'http://taskino.vs/taskino-uploads/taskino/2013-07/ff92a5a047808d57ee9817e7a943de38.png', 1, '129.71', 'taskino', 1, '2013-07-30 18:46:21'),
(11, 46, 1, '', '911a8bff8f8dc16c0d8a14b66ff0a44f.zip', 'application/x-zip-compressed', '/taskino-uploads/taskino/2013-07/911a8bff8f8dc16c0d8a14b66ff0a44f.zip', 'http://taskino.vs/taskino-uploads/taskino/2013-07/911a8bff8f8dc16c0d8a14b66ff0a44f.zip', 0, '0.96', 'taskino', 1, '2013-07-30 18:47:44'),
(16, 46, 1, '', '53a814f647bc7eade306a046574d1c28.jpg', 'image/jpeg', '/taskino-uploads/taskino/2013-08/53a814f647bc7eade306a046574d1c28.jpg', 'http://taskino.vs/taskino-uploads/taskino/2013-08/53a814f647bc7eade306a046574d1c28.jpg', 1, '8.7', 'taskino', 1, '2013-08-07 18:55:27'),
(18, 47, 1, '', '9ed9d6de10a51c2603b4fcd75198403d.png', 'image/png', '/taskino-uploads/in9web/2013-08/9ed9d6de10a51c2603b4fcd75198403d.png', 'http://taskino.vs/taskino-uploads/in9web/2013-08/9ed9d6de10a51c2603b4fcd75198403d.png', 1, '362.62', 'taskino', 1, '2013-08-26 13:52:20');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
