-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tempo de Geração: 
-- Versão do Servidor: 5.5.27
-- Versão do PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `gotask`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_ci_sessions`
--

DROP TABLE IF EXISTS `go_ci_sessions`;
CREATE TABLE IF NOT EXISTS `go_ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `go_ci_sessions`
--

INSERT INTO `go_ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('13271ecbe874a5a1c79a28bd93b74fa1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 1371231397, 'a:1:{s:6:"member";a:6:{s:2:"id";s:1:"1";s:4:"name";s:13:"Wallace Silva";s:5:"email";s:30:"wallace.silva@v7viagens.com.br";s:8:"password";s:40:"7c4a8d09ca3762af61e59520943dc26494f8941b";s:6:"status";s:6:"active";s:10:"date_added";s:19:"2013-06-10 14:44:15";}}');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_members`
--

DROP TABLE IF EXISTS `go_members`;
CREATE TABLE IF NOT EXISTS `go_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(41) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Extraindo dados da tabela `go_members`
--

INSERT INTO `go_members` (`id`, `name`, `email`, `password`, `status`, `date_added`) VALUES
(1, 'Wallace Silva', 'wallace.silva@v7viagens.com.br', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'active', '2013-06-10 14:44:15'),
(3, 'Lucas Ribeiro', 'lucas.ribeiro@wings.travel', '210a28f50a8e9a0986df287ac9ae224de95b8978', 'active', '2013-06-11 23:02:43'),
(4, 'Sandro', 'alexander.balard@wings.travel', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'active', '2013-06-11 23:03:11'),
(5, 'Tamy Ribeiro', 'tamy.ribeiro@wings.travel', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'active', '2013-06-11 23:04:26');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_tasks`
--

DROP TABLE IF EXISTS `go_tasks`;
CREATE TABLE IF NOT EXISTS `go_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `assigned_to` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Extraindo dados da tabela `go_tasks`
--

INSERT INTO `go_tasks` (`id`, `name`, `description`, `assigned_to`, `priority`, `status`, `created_by`, `date_added`) VALUES
(1, 'Primeira tarefa', 'bla bla bla', 1, 4, 2, 1, '2013-06-10 20:15:17'),
(3, 'Alterar template goLogistics2', 'anotado', 1, 2, 1, 1, '2013-06-14 18:36:55'),
(5, 'Tarefa teste', 'dsdsds', 3, 4, 1, 1, '2013-06-11 23:01:04'),
(6, 'Alterar sistema de login no goLogistics', 'Falha permite acessar páginas sem login, assim como sistema de outros clientes.\r\n\r\nex. brasdril poderia acessar dados da sbm somente alterando a url', 1, 2, 1, 1, '2013-06-13 23:08:47');

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_comments`
--

DROP TABLE IF EXISTS `go_task_comments`;
CREATE TABLE IF NOT EXISTS `go_task_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `go_task_todo`
--

DROP TABLE IF EXISTS `go_task_todo`;
CREATE TABLE IF NOT EXISTS `go_task_todo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
